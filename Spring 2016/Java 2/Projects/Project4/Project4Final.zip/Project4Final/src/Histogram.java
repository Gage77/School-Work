
	import java.awt.Color;
	import java.awt.Graphics;
	import java.awt.Graphics2D;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;

	import javax.swing.JComponent;

	/**
	 * Takes in a MediaMaker object and uses information gathered from that object
	 * to construct a histogram.
	 *
	 */
	public class Histogram  extends JComponent{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		/**
		 * Stores every credit the mediaMaker has received.
		 */
		private List<Media> credits;
		
		private ArrayList<Media> movieCredits;
		private ArrayList<Media> episodeCredits;
		/**
		 * Stores a MediaMaker obj from which the information is gathered.
		 */
		private MediaMaker obj;
		/**
		 * Stores the first year a MediaMaker recieved a credit.
		 */
		private int startYear;
		/**
		 * Stores the last year a MediaMaker recieved a credit.
		 */
		private int endYear;
		/**
		 * Stores the height of the field in which the histogram will be drawn.
		 */
		private static final int FIELD_HEIGHT = 400;
		/**
		 * Stores the height of the field in which the histogram will be drawn.
		 */
		private static final int FIELD_WIDTH = 800;
		/**
		 * Stores the x value where the field will begin.
		 */
		private static final int FIELD_X = 50;
		/**
		 * Stores the y value where the field will begin
		 */
		private static final int FIELD_Y = 70;
		/**
		 * Stores the color that will be used for movies acted.
		 */
		 
		static final Color EPISODE_ACTED_COLOR = Color.white;
		/**
		 * Stores the color that will be used for series episodes directed.
		 */
		private static final Color EPISODE_DIRECTED_COLOR = Color.PINK;
		
		/**
		 * Constructor method.
		 * 
		 * @param name
		 *            the name that will be used to get a MediaMaker object from its
		 *            LinkedHashMap.
		 */
		public Histogram(MediaMaker obj) {
			this.obj = obj;
			this.credits = obj.getCredits();
			for(Media a: obj.getCredits()){
				if(a.getMediaType().equals("MOVIE")){
					this.movieCredits.add(a);
				}
				else{
					this.episodeCredits.add(a);
				}
			}		
		}

		/**
		 * This method gets the total number of years of a MediaMakers career.
		 * 
		 * @return the number of years a MediaMaker has worked.
		 */
		private int getYearRange() {
			Collections.sort(credits, new YearComparator());
			this. startYear = credits.get(0).getReleaseYear();
			this. endYear = credits.get(credits.size()-1).getReleaseYear();
			int yearRange = endYear - startYear;
			return yearRange;
		}
		
		private int getEpisodeCredits(int year){
			int creditsForYear = 0;
			for(Media a: this.episodeCredits){
				if (a.getReleaseYear().equals(year)){
					creditsForYear ++;
				}
			}
			return creditsForYear;
		}
		
		private int getMovieCredits(int year){
			int creditsForYear = 0;
			for(Media a: this.movieCredits){
				if (a.getReleaseYear().equals(year)){
					creditsForYear ++;
				}
			}
			return creditsForYear;
		}
	
		/**
		 * Adds bars split into a possibility of six categories to the histogram.
		 * 
		 * @param obj
		 *            The graphics object that the rectangles are to be added to.
		 * @param year
		 *            The year that the bar will display.
		 * @param startPointWidth
		 *            The point on the x-axis where the rectangle will start.
		 * @param width
		 *            The width of the rectangle.
		 */
		private void addRectangle(Graphics obj, int year, int startPointWidth, int width) {

			/*
			 * Stores the number of units each credit should consume.
			 */
			int unitsPerCredit = Math.round(FIELD_HEIGHT / credits.size());
			/*
			 * Stores the total number of credits for each year.
			 */
			int yearCredits = 0;//have to get the number of credits for a given year.
			
			int barHeight = FIELD_HEIGHT - yearCredits + 70;
			/*
			 * Labels the bar for each year of the histogram with the current year.
			 */
			obj.setColor(Color.black);
			obj.drawString(String.valueOf(year), startPointWidth, FIELD_Y + FIELD_HEIGHT + 15);
			
			int episodeCredits = getEpisodeCredits(year) * unitsPerCredit;
			
			int movieCredits = getMovieCredits(year) * unitsPerCredit;
			if (episodeCredits > 0) {
				obj.setColor(EPISODE_ACTED_COLOR);
				obj.fillRect(startPointWidth, barHeight, width, episodeCredits);
				barHeight += episodeCredits;
			}
			if (episodeCredits > 0) {
				obj.setColor(EPISODE_DIRECTED_COLOR);
				obj.fillRect(startPointWidth, barHeight, width, movieCredits);
				barHeight += movieCredits;
			}
		}

		/**
		 * Ovewritten method that allows the histogram to be drawn.
		 */
		public void paint(Graphics g) {
			Graphics2D graphicsObj = (Graphics2D) g;

			graphicsObj.setColor(Color.black);
			/*
			 * Draws the field where the histogram will be housed.
			 */
			graphicsObj.drawRect(FIELD_X, FIELD_Y, FIELD_WIDTH, FIELD_HEIGHT);

			
			/*
			 * Determines the width of each rectangle to be drawn. Divides the total
			 * width of the field by the total number of rectangles to be drawn.
			 */
			int rectangleWidth = Math.round(FIELD_WIDTH / getYearRange());
			int startPointWidth = 50;

			while (startYear < endYear) {
				addRectangle(g, startYear, startPointWidth, rectangleWidth);
				startPointWidth += rectangleWidth;
				startYear++;
			}
		}
	}


