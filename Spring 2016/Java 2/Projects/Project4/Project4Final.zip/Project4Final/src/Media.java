import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * 
 * @author Haley
 *
 */
public class Media implements Comparable<Media> {
	/**
	 * Stores the title of a Media object. Can be accessed with the 'getTitle()'
	 * method.
	 */
	private String title;
	/**
	 * Stores the release year of a Media object. Can be accessed with the
	 * 'getReleaseYear()' method.
	 */
	private Integer releaseYear;
	/**
	 * Stores a list of all actors for a Media object.
	 */
	private List<String> actors;
	/**
	 * Stores a list of all directors for a Media object.
	 */
	private List<String> directors;
	/**
	 * Stores a list of all producers for a Media object.
	 */
	private List<String> producers;

	/**
	 * A constructor.
	 * 
	 * @param title
	 *            The title of a Media object.
	 */
	public Media(String title) {
		this.title = title;

	}

	/**
	 * A constructor
	 * 
	 * @param title
	 *            The title of a Media object.
	 * @param releaseYear
	 *            The year a Media object was released.
	 */

	public Media(String title, Integer releaseYear) {
		this.title = title;
		this.releaseYear = releaseYear;
	}

	/**
	 * A mutator method that adds a Media object to a static list of Media
	 * objects found in this class.
	 * 
	 * @param obj
	 *            The Media object to be added to the list.
	 */
	
	/**
	 * Mutator method that adds an actors name to a Media objects list of
	 * actors.
	 * 
	 * @param name
	 *            The name of the actor.
	 */
	public void addActor(String name) {
		this.actors.add(name);
	}

	/**
	 * Mutator method that adds a directors name to a Media objects list of
	 * directors.
	 * 
	 * @param name
	 *            The name of the director.
	 */
	public void addDirector(String name) {
		this.directors.add(name);

	}

	/**
	 * Mutator method that adds a producers name to a Media objects list of
	 * producers.
	 * 
	 * @param name
	 *            The name of the producer.
	 */
	public void addProducer(String name) {
		this.producers.add(name);
	}

	/**
	 * Allows a Media objects title to be accessed.
	 * 
	 * @return The media objects title.
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * Allows a Media objects release year to be accessed.
	 * 
	 * @return The media objects release year.
	 */
	public Integer getReleaseYear() {
		return this.releaseYear;
	}

	/**
	 * Allows a Media objects list of actors to be accessed.
	 * 
	 * @return The media objects list of actors.
	 */
	public List<String> getActors() {
		return this.actors;
	}

	/**
	 * Allows a Media objects list of directors to be accessed.
	 * 
	 * @return The media objects list of directors.
	 */
	public List<String> getDirectors() {
		return this.directors;
	}

	/**
	 * Allows a Media objects list of producers to be accessed.
	 * 
	 * @return The media objects list of producers.
	 */
	public List<String> getProducers() {
		return this.producers;
	}

	/**
	 * An accessor method that allows the static list of Media objects to be
	 * accessed outside of the Media class.
	 * 
	 * @return Returns the static List of Media objects.
	 */
	

	/**
	 * To be Overriden by Media subclasses. Allows the static List of Media
	 * objects to be seperated by media type.
	 * 
	 * @return Returns a string with the Media object's media type.
	 */
	public String getMediaType() {
		return "";
	}

	/**
	 * Ovewritten method. Should compare the title of Media Objects.
	 */
	@Override
	public int compareTo(Media arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
	final class YearComparator implements Comparator<Media>{

		@Override
		public int compare(Media obj1, Media obj2) {
			return obj1.getReleaseYear().compareTo(obj2.getReleaseYear());
		}}

