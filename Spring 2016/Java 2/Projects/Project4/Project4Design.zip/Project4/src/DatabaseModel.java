import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DatabaseModel 
{
	/** ArrayList of ActionListeners for the model */
	private ArrayList<ActionListener> actionListenerList;
	
	/**
	 * This is the base constructor for DatabaseModel objects
	 */
	public DatabaseModel()
	{
		
	}
	
	/**
	 * This method will add the specified ActionListener to the class
	 * variable actionListenerList
	 * 
	 * @param l		ActionListener to add
	 */
	public void addActionListener(ActionListener l)
	{
		
	}
	
	/**
	 * This method will remove the specified ActionListenr from the 
	 * class variable actionListenerList
	 * 
	 * @param l		ActionListener to remove
	 */
	public void removeActionListener(ActionListener l)
	{
		
	}
	
	/**
	 * This method processes the specified ActionEvent
	 * 
	 * @param e		ActionEvent to process
	 */
	public void processEvent(ActionEvent e)
	{
		
	}
}
