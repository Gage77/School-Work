import java.io.Serializable;
import java.util.ArrayList;

public class Producer implements Serializable
{
	private static final long serialVersionUID = 1L;
	/** ArrayList containing String representation of the producer info */
	private ArrayList<String> producerInfo;
	/** Movies in the producer info */
	private ArrayList<Movie> moviesIn;
	/** Episodes in the producer info */
	private ArrayList<Episode> episodesIn;
	
	/**
	 * This is the base constructor for Producer objects
	 */
	public Producer()
	{
		
	}
	
	/**
	 * This method will take in producer info and parse it into
	 * the class variables 
	 * 
	 * @param info		Info to parse
	 */
	public void parseProducerInfo(String info)
	{
		
	}
}
