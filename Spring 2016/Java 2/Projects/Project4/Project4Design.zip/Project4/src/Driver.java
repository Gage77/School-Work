import java.io.BufferedReader;

/**
 * Project #3
 * CS 2334, Section 010 - Lab 13
 * Hunter Black
 * April 1, 2016
 * <P>
 * This is the driver class for the program, contains the main method. It creates an 
 * ArrayList of Movie objects, an ArrayList of Series objects, and an ArrayList of Object 
 * objects. Uses inputStream to read input from the user. Contains methods to search the
 * ArrayLists of Series and Movie objects to see if user input matches any information of the
 * objects in the list. Contains numerous sort methods for sorting the ArrayLists in a variety
 * of ways, by title and by year. Contains a save method used to save sorted information into
 * a text file.
 * Additionally, all information displayed to the user will now be through GUIs using the 
 * MVC model to organize all information
 * </P>
 * @version 1.0
 */
public class Driver 
{
	
	/** Main Database for the start of the project */
	public static Database mdb;
	
	/**
	 * The main method of the program, which will initiate the 
	 * start of the program and end it
	 * 
	 * @param args		Program arguments
	 */
	public static void main(String[] args) 
	{ 
		
	}
	
	/**
	 * This method will take in a BufferedReader and will commence to 
	 * ask the user for the binary file to load. After this, an empty
	 * new Database will be created and the file will be read, putting
	 * the database object being read into the new Database object
	 * constructed.
	 * 
	 * @param br	BufferedReader for reading user input
	 * @return		This new Database returned will be the read in Database
	 */
	public static Database loadBinary(BufferedReader br)
	{
		return null;
	}
	
	/**
	 * This method will save the found information for the user, either 
	 * into a text file or binary file using user input obtained from
	 * the passed in BufferedReader
	 * 
	 * @param br	BufferedReader for reading user input
	 */
	public static void save(BufferedReader br)
	{
		
	}

}
