import java.io.Serializable;
import java.util.ArrayList;

public class Director implements Serializable
{
	private static final long serialVersionUID = 1L;
	/** ArrayList containing String representation of the directing info */
	private ArrayList<String> directorInfo;
	/** Movies in the directing info */
	private ArrayList<Movie> moviesIn;
	/** Episodes in the directing info */
	private ArrayList<Episode> episodesIn;
	
	/**
	 * This is the base constructor for Director objects
	 */
	public Director()
	{
		
	}
	
	/**
	 * This method will take in director info and parse it into
	 * the class variables 
	 * 
	 * @param info		Info to parse
	 */
	public void parseDirectorInfo(String info)
	{
		
	}

}
