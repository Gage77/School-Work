import java.io.Serializable;
import java.util.ArrayList;

public class MediaMaker implements Comparable<MediaMaker>, Serializable
{

	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/** Last name of the MediaMaker */
	private String lastName;
	/** First name of the MediaMaker */
	private String firstName;
	/** Actor object associated with the MediaMaker, or null if no acting credits exist */
	private Actor acting;
	/** Director object associated with the MediaMaker, or null if no directing credits exist */
	private Director directing;
	/** Producer object associated with the MediaMaker, or null if no producing credits exist */
	private Producer producing;
	
	/**
	 * This is the base constructor for MediaMaker objects,
	 * setting all class variables to null
	 */
	public MediaMaker()
	{
		
	}
	
	/**
	 * This is the main constructor for MediaMaker objects,
	 * setting class variables to specified constructors
	 * 
	 * @param lN	Last name of the MediaMaker
	 * @param fN	First name of the MediaMaker
	 */	
	public MediaMaker(String lN, String fN)
	{
		
	}
	
	/**
	 * Returns the last name of the MediaMaker object
	 * 
	 * @return		Last name of the MediaMaker
	 */
	public String getLastName()
	{
		return null;
	}
	
	/**
	 * Returns the first name of the MediaMaker object
	 * 
	 * @return		First name of the MediaMaker
	 */
	public String getFirstName()
	{
		return null;
	}
	
	/**
	 * This method will take in actor info pertaining to this MediaMaker and 
	 * creates new Actor objects with it, adding the created Actor object
	 * to the class variable acting 
	 * 
	 * @param info		Acting info for this MediaMaker
	 */
	public void parseActorInfo(String info)
	{
		
	}
	
	/**
	 * This method will take in director info pertaining to this MediaMaker and 
	 * creates new Director objects with it, adding the created Director object
	 * to the class variable acting 
	 * 
	 * @param info		Directing info for this MediaMaker
	 */
	public void parseDirectorInfo(String info)
	{
		
	}
	
	/**
	 * This method will take in producing info pertaining to this MediaMaker and 
	 * creates new Producer objects with it, adding the created Producer object
	 * to the class variable acting 
	 * 
	 * @param info		Producing info for this MediaMaker
	 */
	public void parseProducerInfo(String info)
	{
		
	}
	
	/**
	 * Returns a String representation of the MediaMaker object
	 */
	public String toString()
	{
		return null;
	}

	@Override
	/**
	 * Compares two MediaMaker objects names based on their natural order,
	 * returning an int based off of the Comparable Interface's
	 * compareTo method
	 */
	public int compareTo(MediaMaker o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
