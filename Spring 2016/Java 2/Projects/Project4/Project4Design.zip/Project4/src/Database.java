import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class Database implements Serializable
{
	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/** ArrayList containing all available searchable Movie objects */
	public ArrayList<Movie> movies;
	/** ArrayList containing all available searchable Series objects */
	public ArrayList<Series> series;
	/** LinkedHashMap containing all MediaMakers with the key being their name */
	public LinkedHashMap<String, MediaMaker> mediaMakers;
	
	/**
	 * This is the main constructor for the Database object
	 * It will initialize all class variables
	 */
	public Database()
	{
		
	}
	
	/**
	 * This method will take in a Movie object and insert it into 
	 * the class variable movies for later searching
	 * 
	 * @param m		Movie object to be inserted
	 */
	public void insertMovie(Movie m)
	{
		
	}
	
	/**
	 * This method will take in a Series object and insert it into
	 * the class variable series for later searching
	 * 
	 * @param s		Series object to be inserted
	 */
	public void insertSeries(Series s)
	{
		
	}
	
	/**
	 * This method will take in a MediaMaker object and insert it
	 * into the class variable mediaMakers, getting the key 
	 * from the MediaMaker object's getName method
	 * 
	 * @param mm	MediaMaker to be inserted
	 */
	public void insertMediaMaker(MediaMaker mm)
	{
		
	}
	
	/**
	 * This method will utilize the Serializable interface and 
	 * write the Database object into a specified file
	 * 
	 * @param d		Database to be written
	 * @param file	File into which the Database is to be written
	 */
	public static void writeDatabase(Database d, String file)
	{
		
	}
	
	/**
	 * This method will utilize the Serializable interface and
	 * read a specified file containing a Database object and 
	 * putting the read in Database into a newly created Database,
	 * which will then be returned
	 * 
	 * @param file	File from which to read from
	 * @return		The read in Database object
	 */
	public static Database readDatabase(String file)
	{
		return null;
	}
	
}
