import java.io.Serializable;

public class Episode implements Comparable<Episode>, Serializable
{
	
	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/** Title of the Episode */
	private String episodeTitle;
	/** Number of the Episode in the Series */
	private String number;
	/** Release year of the Episode */
	private String releaseYear;

	/**
	 * This is the base constructor for Episode objects,
	 * setting all class variables to null
	 */
	public Episode()
	{
		
	}
	
	/**
	 * This is the main constructor for Episode objects,
	 * setting all class variables to the specified parameters
	 * 
	 * @param eT	Episode title
	 * @param n		Number of the Episode
	 * @param rY	Release year of the Episode
	 */
	public Episode(String eT, String n, String rY)
	{
		
	}
	
	/**
	 * Returns the title of the Episode object
	 * 
	 * @return		Title of the Episode
	 */
	public String getEpisodeTitle()
	{
		return null;
	}
	
	/**
	 * Returns the number of the Episode objects
	 * 
	 * @return		Number of the Episode
	 */
	public String getNumber()
	{
		return null;
	}
	
	/**
	 * Returns the release year of the Episode objects
	 * 
	 * @return		Release year of the Episode
	 */
	public String getReleaseYear()
	{
		return null;
	}
	
	/**
	 * Returns a String representation of the Episode object
	 */
	public String toString()
	{
		return null;
	}
	
	@Override
	/**
	 * Compares two Episode object's title according to their natural order,
	 * returning an int based off of the Comparable Interface's
	 * compareTo method
	 */
	public int compareTo(Episode o) {
		return 0;
	}
}
