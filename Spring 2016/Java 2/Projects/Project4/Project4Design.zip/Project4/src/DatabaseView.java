
public class DatabaseView 
{
	/** The model that the View will pay attention to */
	private DatabaseModel model;
	
	/** 
	 * This is the base constructor for DatabaseView objects
	 */
	public DatabaseView()
	{
		
	}
}
