import java.io.Serializable;

public class Movie implements Comparable<Movie>, Serializable
{

	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/**Title of the Movie */
	private String title;
	/**Year the the Movie was released */
	private String year;
	/**Format of release of the Movie (TV/V) */
	private String format;
	/**Multiple number of the Movie if eligible */
	private String multiple;
	
	/**
	 * This is the base constructor for Movie objects
	 * setting class variables to null
	 */
	public Movie()
	{
		
	}
	
	/**
	 * This is the main constructor for the Movie object,
	 * setting the class variables to the specified parameters
	 * 
	 * @param t		Title 
	 * @param y		Year
	 * @param f		Format of release
	 * @param m		Multiple if eligeable
	 */
	public Movie(String t, String y, String f, String m)
	{
		
	}
	
	/**
	 * Returns the tile of the Movie object
	 * 
	 * @return		Title of the Movie
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * Returns the release year of the Movie object
	 * 
	 * @return		Release year of the Movie
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * Returns the format of release of the Movie object
	 * 
	 * @return		Release format of the Movie
	 */
	public String getFormat()
	{
		return null;
	}
	
	/**
	 * Returns the multiple of the Movie object, if eligible
	 * 
	 * @return		Multiple of the Movie
	 */
	public String getMultiple()
	{
		return null;
	}
	
	/**
	 * Parses a line containing movie information
	 * 
	 * @param line	Line containing movie information
	 */
	public void parse(String line)
	{
		
	}
	
	/**
	 * Returns String representation of the Movie object
	 */
	public String toString()
	{
		return null;
	}
	

	@Override
	/**
	 * Compares the titles of two Movie objects using natural order,
	 * returning an int based off of the Comparable Interface's 
	 * compareTo method
	 */
	public int compareTo(Movie arg0)
	{
		return 0;
	}
	
}
