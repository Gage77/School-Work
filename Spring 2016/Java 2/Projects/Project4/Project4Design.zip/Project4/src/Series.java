import java.io.Serializable;
import java.util.ArrayList;

public class Series implements Comparable<Series>, Serializable
{

	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/** Title of the Series */
	private String title;
	/** Start year of the Series */
	private String startYear;
	/** Range of years the Series aired */
	private String yearRange;
	/** ArrayList of Episode objects associated with this Series */
	private ArrayList<Episode> episodes;
	
	/**
	 * This is the base constructor for Series object,
	 * setting all class variables to null
	 */
	public Series()
	{
		
	}
	
	/**
	 * This is the main constructor for the Series object,
	 * setting all class variables to the specified parameters
	 * 
	 * @param t		Title
	 * @param sY	Start year
	 * @param yR	Year range
	 */
	public Series(String t, String sY, String yR)
	{
		
	}
	
	/**
	 * Parses a line containing all Series information
	 * 
	 * @param line	Line containing information on Series
	 */
	public void parse(String line)
	{
		
	}
	
	/**
	 * Returns the title of the Series object
	 * 
	 * @return		Title of the Series
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * Returns the start year of the Series object
	 * 
	 * @return		Start year of the Series
	 */
	public String getStartYear()
	{
		return null;
	}
	
	/**
	 * Returns the range of years the Series object aired
	 * 
	 * @return		Year range of the Series
	 */
	public String getYearRange()
	{
		return null;
	}
	
	/**
	 * Returns the ArrayList containing all Episode objects
	 * associated with the Series object
	 * 
	 * @return		ArrayList of Episode objects
	 */
	public ArrayList<Episode> getEpisodes()
	{
		return null;
	}
	
	/**
	 * Adds the specified Episode object to the Series object's
	 * class variable episodes
	 * 
	 * @param e		Episode object to add
	 */
	public void addEpisode(Episode e)
	{
		
	}
	
	/**
	 * Returns a String representation of the Series object
	 */
	public String toString()
	{
		return null;
	}

	@Override
	/**
	 * Compares two Series object's titles by their natural order,
	 * returning an int based off of the Comparable Interface's
	 * compareTo method
	 */
	public int compareTo(Series o) {
		return 0;
	}

}
