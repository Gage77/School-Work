import java.io.Serializable;
import java.util.ArrayList;

public class Actor implements Serializable
{

	/**
	 * Default serial version UID
	 */
	private static final long serialVersionUID = 1L;
	/** ArrayList containing String representation of the acting info */
	private ArrayList<String> actorInfo;
	/** Movies in the acting info */
	private ArrayList<Movie> moviesIn;
	/** Episodes in the acting info */
	private ArrayList<Episode> episodesIn;
	
	/**
	 * This is the base constructor for Actor objects
	 */
	public Actor()
	{
		
	}
	
	/**
	 * This method will take in actor info and parse it into
	 * the class variables 
	 * 
	 * @param info		Info to parse
	 */
	public void parseActorInfo(String info)
	{
		
	}

}
