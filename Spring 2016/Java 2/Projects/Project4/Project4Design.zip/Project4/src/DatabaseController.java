
public class DatabaseController 
{
	
	/** The model that this controller will interact with */
	private DatabaseModel model;
	
	/**
	 * This is the base constructor for DatabaseController objects
	 */
	public DatabaseController()
	{
		
	}
	
	/**
	 * This method will set the model that this controller will interact with
	 * 
	 * @param model		The model to set
	 */
	public void setModel(DatabaseModel model)
	{
		
	}
	
	/**
	 * This method will return the model that this controller
	 * is currently interacting with
	 * 
	 * @return		The model
	 */
	public DatabaseModel getModel()
	{
		return null;
	}
}
