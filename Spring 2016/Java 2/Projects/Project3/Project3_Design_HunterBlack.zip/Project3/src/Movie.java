
/**
 * This class will create Movie objects containing information on 
 * movies such as title, release year, format of release, and whether
 * or not it was a multiple release that year
 */

public class Movie implements Comparable <Movie>
{
	
	/** String containing the title of the Movie object */
	private String title;
	/** String containing the release year of the Movie object */
	private String year;
	/** String containing the format of release of the Movie object */
	private String form;
	/** If the movie is a multiple: String containing multiple number of Movie object */
	private String mult;
	
	/**
	 * Base constructor for Movie objects with no parameters, which
	 * will set everything to null
	 */
	public Movie()
	{
		
	}
	
	/**
	 * Constructor for Movie objects which takes in a line containing all of the 
	 * movie information and passes it to the parse method to initialize class
	 * variables
	 * 
	 * @param line	String containing all information on that Movie
	 */
	public Movie(String line)
	{
		
	}
	
	/**
	 * This method will take in a String containing information on a Movie and
	 * parse it into the correct class variables
	 * 
	 * @param line	String containing all information on that Movie
	 */
	private void parse(String line)
	{
		
	}
	
	/**
	 * @return	the title of the Movie
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * @return	the release year of the Movie
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * @return	the format of release of the Movie
	 * 			Will return null if it went to theaters
	 */
	public String getForm()
	{
		return null;
	}
	
	/**
	 * @return	the multiple number of the Movie
	 * 			Will return null if Movie is not a multiple
	 */
	public String getMult()
	{
		return null;
	}
	
	/**
	 * @override	toString
	 * 
	 * @return	String representation of the Movie 
	 * 			object fit for display to user
	 */
	public String toString()
	{
		return null;
	}

	@Override
	/**
	 * Overrides the compareTo method from interface comparable
	 * 
	 * @param m		Movie to compare to
	 * @return		negative int if less than
	 * 				positive int if greater than
	 * 				0 if the same
	 */
	public int compareTo(Movie m) 
	{
		return 0;
	}
	

}
