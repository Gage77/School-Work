import java.util.ArrayList;

public class Actor extends MediaMaker
{
	private ArrayList<Movie> movies;
	private ArrayList<Episode> episodes;
	private int moviesIn = 0;
	private int seriesIn = 0;
	
	public Actor ()
	{
		
	}
	
	public Actor(String info)
	{
		parse(info);
	}
	
	private void parse(String info)
	{
		
	}
}
