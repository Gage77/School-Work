import java.util.LinkedHashMap;

/**
 * This class will instantiate MediaMaker objects which contain
 * information about a specific person such as their name, which
 * number of that name they are, their acting credentials (if any),
 * their directing credentials (if any), and their producing credentials
 * (if any)
 */
public class MediaMaker implements Comparable<MediaMaker>
{
	
	/**	The last name of the MediaMaker */
	private String lastName;
	/**	The first name of the MediaMaker */
	private String firstName;
	/**	The number of that name they are of all MediaMaker objects */
	private String multiple;
	
	/**
	 * The base constructor for this class with no parameters
	 */
	public MediaMaker()
	{
		
	}
	
	/**
	 * The main constructor for this class which takes in a single
	 * String containing all information on a specific person and 
	 * passes it onto the parse method
	 * 
	 * @param info	String containing all information on the MediaMaker
	 */
	public MediaMaker(String last, String first, String mult)
	{
		this.lastName = last;
		this.firstName = first;
		this.multiple = mult;
	}
	
	/**
	 * This method takes in a single String containing all information on
	 * the MediaMaker and parses it into the respective class variables
	 * 
	 * @param info	String containing all information on the MediaMaker
	 */
	private void parse(String info)
	{
		
	}
	
	/**
	 * @return		The last name of the MediaMaker
	 */
	public String getLastName()
	{
		return null;
	}
	
	/**
	 * @return		The first name of the MediaMaker
	 */
	public String getFirstName()
	{
		return null;
	}
	
	/**
	 * @return		The multiple number of the MediaMaker (if any)
	 */
	public String getMultiple()
	{
		return null;
	}
	
	/**
	 * @return		The acting credentials of the MediaMaker (if any)
	 */
	public String getActingInfo()
	{
		return null;
	}
	
	/**
	 * @return		The directing credentials of the MediaMaker (if any)
	 */
	public String getDirectingInfo()
	{
		return null;
	}
	
	/**
	 * @return		The producing credentials of the MediaMaker (if any)
	 */
	public String getProducingInfo()
	{
		return null;
	}
	
	/**
	 * @override	toString
	 * 
	 * @return		String representation of the MediaMaker object
	 * 				fit for display to the user
	 */
	public String toString()
	{
		return null;
	}

	@Override
	/**
	 * Overrides the interface's compareTo method
	 */
	public int compareTo(MediaMaker m) 
	{
		int nameDiff = this.lastName.toLowerCase().compareTo(m.getLastName().toLowerCase());
		if (nameDiff != 0)
			return nameDiff;
		
		return 0;
	}

}
