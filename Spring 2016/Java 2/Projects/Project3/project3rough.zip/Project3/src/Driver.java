import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;

import javax.swing.JFrame;

/**
 *
 * Project #3 with Eclipse as the IDE
 * CS 2334, Section 013
 * Hunter Black
 * 3/7/16
 * 
 * This is the main class of the program. This program will create a 
 * simple user interface which will take in information from the user
 * about movies, TV broadcasts, and people, put them into a database,
 * and allow the user to search through the database for specific info
 *
 */
public class Driver implements Serializable
{
	/**
	 * serialVersionUID for interface Serializable
	 */
	private static final long serialVersionUID = 1L;
	
	/** The media database containing Movie, Series, and Episode objects */
	private static Database mdb;
	/** The people database containing MediaMaker objects */
	private static Database pdb;
	
	private static Database sdb;
	
	/** The main display interface to interact with the user */
	JFrame frame;
	
	
	/**
	 * This is the main method of the program, which enter into the 
	 * filePrompt and questions methods, and then end the program
	 * 
	 * @param args	Program arguments
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException
	{
		mdb = new Database(0);
		pdb = new Database(1);
		sdb = new Database(2);
		
		String fileName = "someActors.txt";
		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		
		pdb.parseActor(fileName, br);
		
		Movie m = new Movie("'Star Trek: Deep Space Nine': Behind the Scenes (1993) (V)  1993");
		System.out.println(m);
		Movie m2 = new Movie("Inside the New Adventure: Star Trek - Voyager (1995)   1995");
		System.out.println(m2);
		Series s = new Series("Star Trek Anthology (2015)				2015-????");
		System.out.println(s);
		Episode e = new Episode("Star Trek: The Continuing Mission (2007) {Command Decision (#1.5)} {{SUSPENDED}}	2009");
		System.out.println(e);
	}
	
	/**
	 * This method will prompt the user for the various files needed
	 * for this program to properly work
	 */
	private void filePrompt()
	{
		
	}
	
	/**
	 * This method will go through a series of questions to determine the 
	 * search parameters from the user. It will then call the respective 
	 * search methods from the Database class. Finally, it will ask the 
	 * user if he/she wishes to save the information to a file
	 * 
	 * @param questionsList		Array of the answers to the questions asked
	 * 							used in other methods to determine search type
	 */
	private void questions(String[] questionsList)
	{
		
	}
}
