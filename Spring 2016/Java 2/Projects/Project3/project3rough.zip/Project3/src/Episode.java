/**
 * This class will instantiate Episode objects which will
 * contain information about the episode such as the series
 * title it is apart of, the year that series aired, the title
 * of the episode, the number of the episode, and the year the 
 * episode aired
 */
public class Episode implements Comparable<Episode>
{
	
	/**	The title of the series the Episode belongs to */
	private String seriesTitle;
	/** The year the series the Episode belongs to first aired */
	private String seriesYear;
	/** The title of the Episode */
	private String episodeTitle;
	/** The number of the Episode */
	private String episodeNumber;
	/** The year the Episode first aired */
	private String episodeYear;
	
	/**
	 * Base constructor for this Class with no parameters
	 */
	public Episode()
	{
		
	}
	
	/**
	 * Main constructor for this class, taking in a single
	 * String containing all information on the Episode and
	 * passing it to the parse method
	 * 
	 * @param line	String containing all information about Episode
	 */
	public Episode(String line)
	{
		parse(line);
	}
	
	/**
	 * This method will take in a single String containing
	 * all information about the Episode and parse it into
	 * the correct class variables
	 * 
	 * @param line	String containing all information about Episode
	 */
	private void parse(String line)
	{
		String[] display = line.split(" ");
	}
	
	/**
	 * @return		Title of the episode
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * @return		Series and episode number of this Episode
	 */
	public String getNumber()
	{
		return null;
	}
	
	/**
	 * @return		Year the episode aired
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * This method will call the Series method addToEpisodes
	 * to add this episode to the corresponding Series object
	 * 
	 * @param s		Series object this Episode is being added to
	 */
	public void addToSeries(Series s)
	{
		
	}
	
	/**
	 * @override	toString
	 * 
	 * @return		String representation of Episode information
	 * 				fit for display to user
	 */
	public String toString()
	{
		if (this.episodeTitle != null)
		{
			return "EPISODE: " + seriesTitle + ": " + episodeTitle + ": " + episodeYear;
		}
		else
		{
			return "EPISODE: "  + seriesTitle + ": " + episodeNumber + ": " + episodeYear;
		}
	}

	@Override
	/**
	 * Overrides the interface's compareTo method
	 */
	public int compareTo(Episode e) 
	{
		return 0;
	}
	
}
