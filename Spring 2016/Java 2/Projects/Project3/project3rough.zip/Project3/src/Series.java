import java.util.ArrayList;

/**
 * This class will initialize Series objects containing 
 * information on series such as title, start year, range 
 * of years airing, and an ArrayList containing all of 
 * that series's episodes
 */
public class Series implements Comparable<Series>
{
	
	/** The title of the series */
	private String title;
	/** The year the series first aired */
	private String startYear;
	/** The range of years the series aired */
	private String yearRange;
	
	/** A list of all of the episodes of this series */
	private ArrayList<Episode> episodes;
	
	/**
	 * Base constructor for this class with no parameters
	 */
	public Series()
	{
		
	}

	/**
	 * Main constructor for this class, taking in a single
	 * String containing all information about this series
	 * and passing it on to the parse method
	 * 
	 * @param line		String containing all series information
	 */
	public Series(String line)
	{
		parse(line);
	}
	
	/**
	 * This method will take in a single String containing 
	 * information on the series and parse it into the correct
	 * class variables
	 * 
	 * @param line		String containing all series information
	 */
	private void parse(String line)
	{
		if (line.contains("{") && line.contains("}"))
		{
			Episode a = new Episode(line);
			episodes.add(a);
		}
		
		String[] divided = line.split(" ");
		yearRange = divided[divided.length - 1];
		startYear = divided[divided.length - 2];
		title = divided[0] + " ";
		
		for (int i = 1; i < divided.length - 2; ++i)
		{
			title += divided[i] + " ";
		}
	}
	
	/**
	 * @return		The title of the series
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * @return		The year the series first aired
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * @return		The range of years the series aired
	 */
	public String getRange()
	{
		return null;
	}
	
	/**
	 * This method will insert an Episode object into the 
	 * ArrayList episodes
	 * 
	 * @param e		Episode object to insert
	 */
	public void insertEpisode(Episode e)
	{
		
	}
	
	/**
	 * @override	toString
	 * 
	 * @return		String representation of all of the series information
	 * 				in format fit for display to user
	 */
	public String toString()
	{
		String seriesReturn = "SERIES: " + title + " " + startYear + " " + yearRange;
		return seriesReturn;
	}
	
	@Override
	/**
	 * Overrides the interface's compareTo method
	 */
	public int compareTo(Series s) 
	{
		return 0;
	}
}
