import java.util.ArrayList;
import java.util.Collections;

/**
 * This class will create Movie objects containing information on 
 * movies such as title, release year, format of release, and whether
 * or not it was a multiple release that year
 */

public class Movie implements Comparable <Movie>
{
	
	/** String containing the title of the Movie object */
	private String title;
	/** String containing the release year of the Movie object */
	private String year;
	/** String containing the format of release of the Movie object */
	private String form;
	/** If the movie is a multiple: String containing multiple number of Movie object */
	private String multiple;
	
	/**
	 * Base constructor for Movie objects with no parameters, which
	 * will set everything to null
	 */
	public Movie()
	{
		
	}
	
	/**
	 * Constructor for Movie objects which takes in a line containing all of the 
	 * movie information and passes it to the parse method to initialize class
	 * variables
	 * 
	 * @param line	String containing all information on that Movie
	 */
	public Movie(String line)
	{
		parse(line);
	}
	
	/**
	 * This method will take in a String containing information on a Movie and
	 * parse it into the correct class variables
	 * 
	 * @param line	String containing all information on that Movie
	 */
	private void parse(String line)
	{
		String[] divided = line.split(" ");
		year = divided[divided.length - 1]; //Last item in divided ArrayList always the release year
		
		//step backwards in divided ArrayList starting after the release year 
		ArrayList<String> title0 = new ArrayList<String>(); //For holding title strings
		for (int i = divided.length - 2; i >= 0; --i)
		{
			//Check for form, i.e. TV or V by using .contains and .substring
			if (divided[i].contains("(TV)") || divided[i].contains("(V)"))
			{
				if (divided[i].contains("(TV)"))
					form = divided[i].substring(1,3);
				else
					form = divided[i].substring(1,2);
			}
			//Check for multiple (I, II, III, IV) using .contains and .substring
			else if (divided[i].contains("/I") || divided[i].contains("/II") || divided[i].contains("/III") || divided[i].contains("/IV"))
			{
				multiple = divided[i];
			}
			else
			{
				title0.add(divided[i]);
			}
		}
		
		//Because I was stepping backwards through "line", title0 is reverse of what i need
		//So i need to reverse it, then convert it to a string using a for/each loop
		Collections.reverse(title0);
		String title1 = "";
		for (String s : title0)
		{
			title1 += s + " ";
		}
		
		title = title1;
	}
	
	/**
	 * @return	the title of the Movie
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * @return	the release year of the Movie
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * @return	the format of release of the Movie
	 * 			Will return null if it went to theaters
	 */
	public String getForm()
	{
		return null;
	}
	
	/**
	 * @return	the multiple number of the Movie
	 * 			Will return null if Movie is not a multiple
	 */
	public String getMult()
	{
		return null;
	}
	
	/**
	 * @override	toString
	 * 
	 * @return	String representation of the Movie 
	 * 			object fit for display to user
	 */
	public String toString()
	{
		String movieInfo = "";
		if (multiple != null)
			movieInfo = "MOVIE " + "(" + form + "): " + title + multiple + " " + year;
		else 
			movieInfo = "MOVIE " + "(" + form + "): " + title + " " + year;
		if (form == null)
			movieInfo = "MOVIE: " + title + " " + year;
		return movieInfo;
	}

	@Override
	/**
	 * Overrides the compareTo method from interface comparable
	 * 
	 * @param m		Movie to compare to
	 * @return		negative int if less than
	 * 				positive int if greater than
	 * 				0 if the same
	 */
	public int compareTo(Movie m) 
	{
		int movieDiff = this.title.toLowerCase().compareTo(m.getTitle().toLowerCase());
		if (movieDiff != 0)
			return movieDiff;
		return 0;
	}
	

}
