public class Episode extends Media {
	
	private static final long serialVersionUID = 1L;
	private String seriesName;
	private String episodeNumber;
	
	public Episode() {
		
	}

	public Episode(String eTitle, String sTitle, String eNumber, String year) {
		super(eTitle, year);
		seriesName = sTitle;
		episodeNumber = eNumber;
	}

	/**
	 * Sets the name of the series
	 * 
	 * @param seriesName		Name of series to set
	 */
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}

	/**
	 * Sets the episode number 
	 * 
	 * @param episodeNumber		Number of the episode
	 */
	public void setEpisodeNumber(String episodeNumber) {
		this.episodeNumber = episodeNumber;
	}

	/**
	 * Returns the name of the series this episode is in
	 * 
	 * @return		Name of the series 
	 */
	public String getSeriesName() {
		return this.seriesName;
	}

	/**
	 * Returns the number of the episode
	 * 
	 * @return		Number of the episode
	 */
	public String getEpisodeNumber() {
		return this.episodeNumber;
	}

	/**
	 * This method overrides the super class's getMediaType method,
	 * returning "Episode"
	 */
	@Override
	public String getMediaType() {
		return "EPISODE";
	}

	/**
	 * Overrides the toString method, returning a string representation
	 * of the object
	 */
	public String toString() {
		return "EPISODE: " + "(" + this.seriesName + "): " + this.title + "(" + this.episodeNumber + ") " + this.releaseYear;
	}
}