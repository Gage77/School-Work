import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class ParseFile extends Driver {
	
	/**
	 * This method contains the specific numbers that are digits. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isDigit(char c){
		return c>= '0' && c <= '9';
	}
	
	/**
	 * This method contains the specific characters that are considered spaces or tabs. 
	 * It helps the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean whiteSpace(char c) {
	 return	c == ' ' || c == '\t';
	}
	
	/**
	 * This method contains the specific characters that are parentheses. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isParentheses(char c) {
		return c == '(' || c == ')';	
	}
	
	/**
	 * This method contains the specific numbers that are digits. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isReleaseType(char c) {
		return c == 'T' || c == 'V';
	}
	
	private final static boolean removeQuestionMark(char c) {
		return c == '?';
	}
	
	
	/**
	 * This method is to use a line from a file to create a Movie object. This
	 * method should simultaneously create the Movie object and add it to the
	 * List parameter. It should also check to see if the Media object already
	 * exists in the list before adding it 
	 * 
	 * @param line			The line to be parsed	
	 * @return				The new Movie object being created
	 */
	public static Movie parseMovie(String line) {

		/** String year
		 *  the year of the movie.
		 *  This will be converted to a Integer below.
		 */
		 String year = "";
		 
		 /** String movieName
		  *  the name of the movie
		  */
		 String movieName = "";
		 
		 /** String movieInfo
		  *  contains additional information
		  *  of the movie
		  */
		 String movieInfo = "";
		 
		 /** String releaseInfo
		  *  contains information on how the movie was released
		  */
		 String releaseInfo = "";
		 
		 /** General Idea: treat the line like a character array.
		  * Make use of the string.charAt(int) method, to retrieve
		  * characters from the string. Keep an index variable to track
		  * where in the array you are.*/
		 
		 int index = line.length()-1;
		 
		 // Parse year
		 while (isDigit(line.charAt(index)))
		 {
			 year = line.charAt(index) + year;
			 index--;
		 }
		 
		 // If no year was parsed, remove any question marks
		 if (year.length() == 0) {
			 while (removeQuestionMark(line.charAt(index))) {
				 index--;
			 }
		 }
		 
		 /*Skip whitespace*/
		 while (whiteSpace(line.charAt(index))) 
		 {
			 index--;
			 
			 if (isParentheses(line.charAt(index))) 
			 {
				 index--; // removes first parentheses
				 
				 while (isReleaseType(line.charAt(index))) 
				 {
					 // stores the release info of each movie object
					 releaseInfo = line.charAt(index) + releaseInfo;
					 index--;
					 
					 if (isParentheses(line.charAt(index))) 
					 {
						 index--; // skips the last parentheses
					 } 
				 }
				 
				 // If there are question marks in parentheses, remove the question marks
				 while (removeQuestionMark(line.charAt(index))) {
					index--;
					
					if (isParentheses(line.charAt(index))) {
						index--;
					}
				 }
				 
				 // this while statement will check for additional movie
				 // information
				 while (isDigit(line.charAt(index))) 
				 {
					movieInfo = line.charAt(index) + movieInfo;
					index--;
							
					if (isParentheses(line.charAt(index))) {
						index--;
					}
				 }
			 }
		 }
		 // the remaining index should contain the title:
		 while (index >= 0)
		 {
			 movieName = line.charAt(index) + movieName;
			 index--;	 
		 }
		
//		 Integer yearReleased;
//		 // If the line did not contain a year number, parse yearReleased as 0
//		 if (year.length() == 0) {
//			 yearReleased = new Integer(0);
//		 } else {
//			yearReleased = Integer.parseInt(year);
//		 }
		 
		 Movie newMovie = new Movie(movieName, year, releaseInfo);
		 return newMovie;
	}
	
	
	

	/**
	 * This method will take a line from a file and create a Series object.This
	 * method should simultaneously create the Series object and add it to the
	 * List parameter . It should also check to see if the Media object already
	 * exists in the list before adding it using
	 * "list.contains(new object here);"
	 * 
	 * @param line
	 * @param list
	 * @throws IOException 
	 */
	public static void parseSeries(File file, ArrayList<Media> series, ArrayList<Media> episodes) throws IOException {
		String line = "";
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
				
		while((line = br.readLine()) != null) 
		{
			String releaseYear = "";

			String[] divided = line.split(" ");
			String seriesTest = divided[divided.length - 1];
			//Series creator
			if (seriesTest.contains("-"))
			{
				String title = "";
				String[] tabDivide = divided[divided.length - 1].split("\t");
				String releaseYearRange = tabDivide[tabDivide.length - 1];
				releaseYear = releaseYearRange.substring(0, 4);
				for (int i = 0; i < divided.length - 1; ++i)
				{
					if (divided[i].contains("(") && divided[i].contains(")"))
					{
						break;
					}
					else
					{
						title = title + divided[i] + " ";
					}
				}
				Series newSeries = new Series(title, releaseYear, releaseYearRange);
				System.out.println(newSeries);
				series.add(newSeries);
			}
			
			//Episode creator
			else
			{
				int titleIndex = 0;
				String episodeTitle = "";
				String episodeNumber = "";
				String episodeTitleNumber = "";
				String episodeReleaseYear = "";
				String seriesTitle = "";
				String[] tabDivide = divided[divided.length - 1].split("\t");
				
				for (int i = 0; i < divided.length; ++i)
				{
					if (divided[i].contains("{"))
					{
						titleIndex = i;
						break;
					}
				}
				for (int i = titleIndex; i <divided.length; ++i)
				{
					episodeTitleNumber = episodeTitleNumber + divided[i] + " ";		
				}
				episodeTitleNumber = episodeTitleNumber.replace("{", "");
				episodeTitleNumber = episodeTitleNumber.replace("}", "");
				//System.out.println(episodeTitleNumber);
				
				String[] episodeInfoDivided = episodeTitleNumber.split(" ");
				episodeReleaseYear = tabDivide[tabDivide.length - 1];
				//System.out.println(episodeReleaseYear);
				for (int i = 0; i < episodeInfoDivided.length - 1; ++i)
				{
					if (episodeInfoDivided[i].contains("."))
					{
						break;
					}
					else
					{
						episodeTitle = episodeTitle + episodeInfoDivided[i] + " ";
					}
				}
				for (int i = 0; i < divided.length - 1; ++i)
				{
					if (divided[i].contains("."))
					{
						episodeNumber = divided[i];
					}
				}
				//System.out.println(episodeTitle);		
				
				for (int i = 0; i < divided.length - 1; ++i)
				{
					if (divided[i].contains("(") && divided[i].contains(")"))
					{
						break;
					}
					else
					{
						seriesTitle = seriesTitle + divided[i] + " ";
					}
				}
				seriesTitle.replace("\"", "");
				//System.out.println(seriesTitle);
				
				Episode newEpisode = new Episode(episodeTitle, seriesTitle, episodeNumber, episodeReleaseYear);
				episodes.add(newEpisode);
				System.out.println(newEpisode);
				for (int i = 0; i < series.size(); ++i)
				{
					if (series.get(i).getTitle().contains(seriesTitle))
					{
						Series inputSeries = (Series)series.get(i);
						inputSeries.addEpisode(newEpisode);
					}
				}
			}
		}
		br.close();
	}

	
	
	
	/**
	 * This method will parse MediaMaker objects, creating new Movie, Series, and Episode
	 * objects when required and adding them to the passed in list. Additionally, after creating
	 * these Media objects, they will be added to the created MediaMaker object
	 * 
	 * @param file					File to parse
	 * @param mediaMakerType		Type of MediaMaker object to create
	 * @param movies				List of Movie objects to add new movies to
	 * @param seriesList			List of Series objects to add new series to
	 * @param episodes				List of Episode objects to add new episodes to
	 * @param mms					List of MediaMaker objects to add created MediaMaker to
	 * @throws IOException
	 */
	public static void parseCredits(File file, String mediaMakerType, ArrayList<Media> movies, ArrayList<Media> seriesList, 
			ArrayList<Media> episodes, ArrayList<MediaMaker> mms, LinkedHashMap<String, MediaMaker> lhmMap, 
			ArrayList<String> names) throws IOException 
	{
		
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
				
		String line = "";
		String name = "";
		String tempName = "";
		
		String mediaInfo = "";
								
		while ((line = br.readLine()) != null)
		{
			
			//Parse the name of the MediaMaker
			String[] firstTabSplit = line.split("\t");
			if (firstTabSplit[0].length() > 1) 
			{
				tempName = firstTabSplit[0];
				String[] nameSplit = tempName.split(" ");
				if (nameSplit.length == 2)
				{
					name = nameSplit[1];
					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
				}
				else if (nameSplit.length == 3)
				{
					name = nameSplit[1];
					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
					name = name + " " + nameSplit[2];
				}
				else if (nameSplit.length == 4)
				{
					name = nameSplit[1];
					name = name + " " + nameSplit[2];
					name = name + " " + nameSplit[3];
					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
				}
				//Adds the name to the overall name list if not already present, and then the actors list
				if (!names.contains(name))
				{
					names.add(name);
					if (mediaMakerType.equals("Actor"))
					{
						Actor actor = new Actor(name);
						mms.add(actor);
						MediaMaker mm = new MediaMaker(name);
						mm.setActor(actor);
						lhmMap.put(name, mm);
					}
					else if (mediaMakerType.equals("Director"))
					{
						Director director = new Director(name);
						mms.add(director);
						MediaMaker mm = new MediaMaker(name);
						mm.setDirector(director);
						lhmMap.put(name, mm);
					}
					else if (mediaMakerType.equals("Producer"))
					{
						Producer producer = new Producer(name);
						mms.add(producer);
						MediaMaker mm = new MediaMaker(name);
						mm.setProducer(producer);
						lhmMap.put(name, mm);
					}
				}
				else if (names.contains(name))
				{
					if (mediaMakerType.equals("Actor"))
					{
						Actor actor = new Actor(name);
						mms.add(actor);	
						lhmMap.get(name).setActor(actor);
					}
					else if (mediaMakerType.equals("Director"))
					{
						Director director = new Director(name);
						mms.add(director);
						lhmMap.get(name).setDirector(director);
					}
					else if (mediaMakerType.equals("Producer"))
					{
						Producer producer = new Producer(name);
						mms.add(producer);
						lhmMap.get(name).setProducer(producer);
					}
				}
			}
			
			mediaInfo = firstTabSplit[firstTabSplit.length - 1];
			String[] mediaInfoSplit = mediaInfo.split(" ");
			String title = "";
			String releaseYear = "";
			String venue = "";
			
			String seriesTitle = "";
			String episodeTitle = "";
			String episodeNumber = "";
			
			//New Movie to create and add to current MediaMaker
			if (!mediaInfoSplit[0].contains("\""))
			{
				//get title of movie
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains(")"))
					{
						break;
					}
					else
					{
						title = title + " " + mediaInfoSplit[i];
					}
				}
				//get release year of the movie
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].length() == 6)
					{
						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
					}
					else if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains("/"))
					{
						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
					}
				}
				//get venue of the movie
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("(V)") || mediaInfoSplit[i].contains("(TV)"))
					{
						venue = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
					}
				}
				
				//Create new Movie object, and add it to the list of Movies if not already present, as well ass
				//the current MediaMaker
				Movie movie = new Movie(title, releaseYear, venue);
				
				//Add specified MediaMaker to the Movie
				if (mediaMakerType.equals("Actor"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							movie.addActor((Actor)mms.get(i));
				}
				else if (mediaMakerType.equals("Director"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							movie.addDirector((Director)mms.get(i));
				}
				else if (mediaMakerType.equals("Producer"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							movie.addProducer((Producer)mms.get(i));
				}
				
				if (!movies.contains(movie))
					movies.add(movie);
				
				if (names.contains(name))
				{
					for (int i = 0; i < mms.size(); ++i)
					{
						if (mms.get(i).getName().equals(name))
							mms.get(i).addMovieCredit(movie);
					}
				}
			}
			
			//New Episode to create and add to respective lists
			else if (mediaInfoSplit[0].contains("\""))
			{
				//get the series title
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("("))
						break;
					else 
						seriesTitle = seriesTitle + " " + mediaInfoSplit[i];
				}
				//get the release year for the series
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].length() == 6)
					{
						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
					}
				}
				//get the episode title
				int episodeTitleIndex = 0;
				for (int i = 0; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("{"))
						episodeTitleIndex = i;
				}
				for (int i = episodeTitleIndex; i < mediaInfoSplit.length; ++i)
				{
					if (mediaInfoSplit[i].contains("#") || (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains("-")))
					{
						episodeNumber = mediaInfoSplit[i];
						break;
					}
					else if (mediaInfoSplit[i].contains("[") || mediaInfoSplit[i].contains("archive"))
						break;
					else
					{
						episodeTitle = episodeTitle + " " + mediaInfoSplit[i];
					}
				}
				//fix up the title and number
				episodeTitle = episodeTitle.replace("{", "");
				episodeNumber = episodeNumber.replace("(", " ");
				episodeNumber = episodeNumber.replace(")", " ");
				episodeNumber = episodeNumber.replace("{", " ");
				episodeNumber = episodeNumber.replace("}", " ");
				
				Series series = new Series(seriesTitle, releaseYear, " ");
				Episode episode = new Episode(episodeTitle, seriesTitle, episodeNumber, releaseYear);
				
				if (!seriesList.contains(series))
				{
					seriesList.add(series);
				}
				for (int i = 0; i < seriesList.size(); ++i)
				{
					if (seriesList.get(i).getTitle().equals(seriesTitle))
					{
						((Series) seriesList.get(i)).addEpisode(episode);
					}
				}
				
				//Add created MediaMaker to the episode
				if (mediaMakerType.equals("Actor"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							episode.addActor((Actor)mms.get(i));
				}
				else if (mediaMakerType.equals("Director"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							episode.addDirector((Director)mms.get(i));
				}
				else if (mediaMakerType.equals("Producer"))
				{
					for (int i = 0; i < mms.size(); ++i)
						if (mms.get(i).getName().equals(name))
							episode.addProducer((Producer)mms.get(i));
				}
				
				if (!episodes.contains(episode))
					episodes.add(episode);
				if (names.contains(name))
				{
					for (int i = 0; i < mms.size(); ++i)
					{
						if (mms.get(i).getName().equals(name))
							mms.get(i).addEpisodeCredit(episode);
					}
				}
			}						
		}
		
		for (MediaMaker mm : mms)
			mm.removeMovieCredit(mm.getMovieCredits().size() - 1);

		br.close();
	}

}
