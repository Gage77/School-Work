import java.io.Serializable;
import java.util.ArrayList;

public class MediaMaker implements Serializable {
	
	private static final long serialVersionUID = 1L;
	/** The name of the MediaMaker */
	private String name;
	/** The type of MediaMaker (Actor, Director, Producer) */
	private String makerType;
	/** A list of all associated movie credits */
	private ArrayList<Movie> movies = new ArrayList<Movie>();
	/** A list of all associated episode credits */
	private ArrayList<Episode> episodes = new ArrayList<Episode>();
	/** If this MediaMaker is an Actor, this is their Actor tag */
	private Actor actor;
	/** If this MediaMaker is an Director, this is their Actor tag */
	private Director director;
	/** If this MediaMaker is an Director, this is their Actor tag */
	private Producer producer;


	/**
	 * This is the base constructor for MediaMaker objects
	 */
	public MediaMaker() {
		
	}
	/**
	 * This is the main constructor for MediaMaker objects
	 * 
	 * @param name			The name of the MediaMaker
	 */
	MediaMaker(String name, String makerType) {
		this.name = name;
		this.makerType = makerType;
	}
	
	/**
	 * This is an overloaded constructor
	 * 
	 * @param name			The name of the MediaMaker
	 */
	MediaMaker(String name) {
		this.name = name;
	}

	/**
	 * This method sets the name of the MediaMaker object
	 * 
	 * @param name			The name to be set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * This method will set the Actor if this MediaMaker is an Actor in some Media
	 * 
	 * @param actor			Actor to set
	 */
	public void setActor(Actor actor) {
		this.actor = actor;
	}
	
	/**
	 * This method will set the Director if this MediaMaker is a Director in some Media
	 * 
	 * @param director		Director to set
	 */
	public void setDirector(Director director) {
		this.director = director;
	}
	
	/**
	 * This method will set the Producer if this MediaMaker is a Producer in some Media
	 * 
	 * @param producer		Producer to set
	 */
	public void setProducer(Producer producer) {
		this.producer = producer;
	}
	
	/**
	 * Will return true if this MediaMaker has Acting credits
	 * 
	 * @return				boolean
	 */
	public boolean hasActor() {
		if (this.actor != null)
			return true;
		else
			return false;
	}
	
	/**
	 * Will return true if this MediaMaker has Directing credits
	 * 
	 * @return				boolean
	 */
	public boolean hasDirector() {
		if (this.director != null)
			return true;
		else
			return false;
	}
	
	/**
	 * Will return true if this MediaMaker has Producing credits
	 * 
	 * @return				boolean
	 */
	public boolean hasProducer() {
		if (this.producer != null)
			return true;
		else
			return false;
	}

	/**
	 * This method will add the specified Movie credit to the
	 * movies list of the associated MediaMaker
	 * 
	 * @param m				The movie to add
	 */
	public void addMovieCredit(Movie m) {
		movies.add(m);
	}
	
	/**
	 * This method will add the specified Episode credit to the
	 * episodes list of the associated MediaMaker
	 * 
	 * @param e				The Episode to add
	 */
	public void addEpisodeCredit(Episode e) {
		episodes.add(e);
	}

	/**
	 * This method removes the Movie object from the specified 
	 * index in the movies list of the MediaMaker
	 * 
	 * @param index			Index of the Movie to remove
	 */
	public void removeMovieCredit(int index) {
		movies.remove(index);
	}
	
	/**
	 * This method removes the Episode object from the specified
	 * index in the episodes list of the MediaMaker
	 * @param index
	 */
	public void removeEpisodeCredit(int index) {
		episodes.remove(index);
	}
	
	/**
	 * This method clears the MediaMaker's movies list
	 */
	public void clearMovieCredits() {
		movies.clear();
	}
	
	/**
	 * This method clears the MediaMaker's episodes list
	 */
	public void clearEpisodeCredits() {
		episodes.clear();
	}

	/**
	 * This method returns the name of the MediaMaker
	 * 
	 * @return				Name of the MediaMaker
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * This method returns the Movie credits of the MediaMaker
	 * 
	 * @return				List of movie credits of the MediaMaker
	 */
	public ArrayList<Movie> getMovieCredits() {
		return this.movies;
	}
	
	/**
	 * This method returns the Episode credits of the MediaMaker
	 * 
	 * @return				List of the episode credits of the MediaMaker
	 */
	public ArrayList<Episode> getEpisodeCredits() {
		return this.episodes;
	}

	/**
	 * This method returns the type of the MediaMaker
	 * 
	 * @return				The type of MediaMaker
	 */
	public String getMakerType() {
		return this.makerType;
	}
	
	public String toString() {
		return "MEDIA-MAKER: " + this.name;
	}
	
}