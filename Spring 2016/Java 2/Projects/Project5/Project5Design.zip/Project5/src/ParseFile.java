import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

public class ParseFile extends Driver {
	
	/**
	 * This method is to use a line from a file to create a Movie object. This
	 * method should simultaneously create the Movie object and add it to the
	 * List parameter. It should also check to see if the Media object already
	 * exists in the list before adding it 
	 * 
	 * @param line
	 * @param list
	 */
	public static Movie parseMovie(String line) {
		return null;
	}

	/**
	 * This method will take a line from a file and create a Series object.This
	 * method should simultaneously create the Series object and add it to the
	 * List parameter . It should also check to see if the Media object already
	 * exists in the list before adding it using
	 * "list.contains(new object here);"
	 * 
	 * @param line
	 * @param list
	 */

	public static Series parseSeries(String line) {
		return null;
	}

	/**
	 * This method will take a line from a file and use it to add acting credits
	 * to a MediaMaker object stored in a LinkedHashMap.
	 * 
	 * 1st: The method will isolate an actor NAME, create a MediaMaker object
	 * which will be stored in the HashMap. The actors name will be the key, The
	 * MediaMaker object will be the value stored.
	 * 
	 * 
	 * **When a MediaMaker object is created it will initialize several empty
	 * ArrayLists of <Series> or <Movies> which can be accessed with the
	 * MediaMaker class' add methods.**
	 * 
	 * 2nd: The method will call parseMovie or parseSeries depending on the
	 * Media Type. Some kind of marker will be used to determine which type
	 * we're dealing with.
	 * 
	 * 3rd: The Movie or Series will be added to the LinkedHashMap. You can
	 * access the object with
	 * The parse
	 * movie method will add any movies to the list of Media objects that arent
	 * already in there so dont worry about doing that here.
	 * 
	 * ***NOTE*** We will have to nest this process in some kind of loop that
	 * repeats it until it comes across a line that has a new actor's name.
	 * 
	 * 
	 * @param fileLine
	 *            A line from the Actors file.
	 * @param people
	 *            A HashMap where the info will be stored.
	 */
	public static MediaMaker parseCredits(String line) {
		return null;
	}

}
