import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 * Project #4 CS 2334, Section 013 4/13/16
 * <p>
 * This class will satisfy the controller portion of the MVC design plan
 * </p>
 * 
 * @version 1.0
 *
 */
public class MediaController {

	/** This will be the model that this controller is connected to */
	MediaModel model;
	
	/** This will be the selection view controller listens to and interacts with */
	private SelectionView slView;
	
	/** This will be the AddView that this controller listens and interacts with */
	private AddView addView;
	
	/** This will be the EditView that this controller listens and interacts with */
	private EditView editView;

	/**
	 * The base constructor for this object
	 */
	public MediaController() {

	}

	// Create private class listeners for the radio buttons
	private class AddMediaListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddMoviesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddSeriesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddEpisodesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddMakersListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

		}
	}

	private class AddActorsListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

		}
	}

	private class AddDirectorsListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

		}
	}

	private class AddProducersListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
		
		}	
	}

	// Create private classes for the JMenu jmFile
	private class AddSaveListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddLoadListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddImportListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
	
		}	
	}

	private class AddExportListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	// Create the private class listeners for the JMenu jmEdit
	private class AddAddListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}		
	}

	
	private class AddAddButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	

	private class AddEditListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	private class AddEditButtonListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddDeleteListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddClearListener implements ActionListener {

		public String getSelectedButtonText() {
			
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	private class AddClearAllListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	// Create private class listeners for the JMenu jmDisplay
	private class AddPieChartListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

		}
	}

	private class AddHistogramListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			 }
		}
	
	private class AddDoSListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			 }
		}

	/**
	 * This method will set the MediaModel for this controller
	 * 
	 * @param newModel
	 *            The MediaModel to be assigned to this controller
	 */
	public void setModel(MediaModel newModel) {

	}

	/**
	 * This method will return the MediaModel associated with this controller
	 * 
	 * @return The MediaModel associated with this controller
	 */
	public MediaModel getModel() {

	}

	/**
	 * This method will set the SelectionView for this controller, as well as
	 * register all listeners associated with that SelectionView
	 * 
	 * @param view
	 *            The SelectionView to be assigned to the controller
	 */
	public void setSelectionView(SelectionView view) {
		
	}
	
	/**
	 * Sets the AddView for this controller 
	 * 
	 * @param view		AddView to be set
	 */
	public void setAddView(AddView view) {
		
	}
	
	/**
	 * Sets the EditView for this Controller
	 * 
	 * @param view		EditView to be set
	 */
	public void setEditView(EditView view) {
		
	}
	
	/**
	 * Sets the DoSView for this Controller
	 * 
	 * @param view		DoSListView to be set
	 */
	public void setDoSView(DoSListView view) {
		
	}

	/**
	 * This method will return the SelectionView associated with this controller
	 * 
	 * @return The SelectionView associated with this controller
	 */
	public SelectionView getSelectionView() {

	}

}