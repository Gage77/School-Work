import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

//Creates a pie-chart. The created PieChart must be added to a visible JFrame or comprable frame to be viewed.

/**
 * Constructs a pie chart that displays acting, directing, and producing credits
 * for one media maker.
 *
 */
public class PieChart extends JComponent {
	/**
	 * Stores the height of the pie chart.
	 */
	private static final Integer CHART_HEIGHT = 300;
	/**
	 * Stores the width of the pie chart.
	 */
	private static final Integer CHART_WIDTH = 300;
	/**
	 * Stores the x-coordinate of the pie chart.
	 */
	private static final Integer CHART_X = 110;
	/**
	 * Stores the y-coordinate of the pie chart.
	 */
	private static final Integer CHART_Y = 80;
	/**
	 * Stores the MediaMaker object to be used.
	 */
	private MediaMaker obj;
	/**
	 * Stores a list of all the MediaMaker's credits.
	 */
	private ArrayList<Media> makerCredits;

	/**
	 * A constructor method.
	 * 
	 * @param obj
	 *            The MediaMaker object whose information will be used to draw
	 *            the pie chart.
	 */
	public PieChart(String name) {

	}

	/**
	 * Adds a Slice to the pie chart.
	 * 
	 * @param obj
	 *            The graphics obj to which the slice will be added.
	 * @param list
	 *            The list of all the credits for one MediaMaker in one
	 *            category.
	 * @param totalCredits
	 *            The total number of credits recieved for one MediaMaker.
	 * @param startPoint
	 *            The point at which the slice will begin.
	 * @return The point at which the previously drawn slice ended. It will be
	 *         used if another slice is added in the future.
	 */

	private Integer addSlice(Graphics2D obj, List<Media> list, Integer totalCredits, Integer startPoint) {

	}

	/**
	 * Overwritten method, allows the piechart to be drawn.
	 */
	public void paint(Graphics g) {

	}

}

