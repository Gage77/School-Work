/**
 * This class will be used to construct and manage Movie objects.
 * 
 * @author Haley
 *
 */
public class Movie extends Media {
	/**
	 * Stores which venue the Movie was released on.
	 */
	private String venue;

	/**
	 * A constructor.
	 * 
	 * @param title
	 *            The title of the Movie object.
	 * @param releaseYear
	 *            The release year of the Movie object.
	 * @param venue
	 *            The venue of the Movie object.
	 */
	public Movie(String title, Integer releaseYear, String venue) {

	}

	/**
	 * An accessor method.
	 * 
	 * @return Returns the venue of the Movie object.
	 */
	public String getVenue() {
	
	}

	/**
	 * Returns the media type of the Media object; in this case movie. Allows
	 * Media objects stored in a List to be seperated by media type.
	 * 
	 * @return Returns the string "MOVIE."
	 */
	@Override
	public String getMediaType() {

	}

	/**
	 * Allows the Movie object to be displayed in String format.
	 */
	public String toString() {

	}
}