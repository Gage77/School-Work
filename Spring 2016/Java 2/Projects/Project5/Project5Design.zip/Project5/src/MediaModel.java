import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MediaModel {
	/** This is the ArrayList that will contain all ActionListeners associated with this model */
	private ArrayList<ActionListener> listeners = new ArrayList<ActionListener>();
	/** This is the LinkedHashMap that contains all MediaMakers */
	private LinkedHashMap<String, MediaMaker> people = new LinkedHashMap<String, MediaMaker>();
	/** This is the ArrayList that contains all Media objects */
	private ArrayList<Media> media = new ArrayList<Media>();
	/** This is the ArrayList that contains all Movie objects */
	private ArrayList<Media> movies = new ArrayList<Media>();
	/** This is the ArrayList that contains all Series objects */
	private ArrayList<Media> series = new ArrayList<Media>();
	/** This is the ArrayList that contains all Episode objects */
	private ArrayList<Media> episodes = new ArrayList<Media>();
	/** This is the ArrayList that contains all Actor objects */
	private ArrayList<MediaMaker> actors = new ArrayList<MediaMaker>();
	/** This is the ArrayList that contains all Director objects */
	private ArrayList<MediaMaker> directors = new ArrayList<MediaMaker>();
	/** This is the ArrayList that contains all Producer objects */
	private ArrayList<MediaMaker> producers = new ArrayList<MediaMaker>();

	/**
	 * This method takes in a File from the MediaController and sends it to the ParseFile class
	 * to be parsed
	 * 	
	 * @param file		File to be parsed
	 * @param type		Type of objects in the file
	 */
	public void parseSelectedFile(File file, String type) {
		
	}

	//Create methods to add objects to the Model's various class variables
	public void addObjectMedia(Media obj) {
		
	}
	public void addObject(Movie m) {
		
	}

	public void addObject(Series s) {
	
	}

	public void addObject(Episode e) {
		
	}
	
	public void addObject(MediaMaker obj) {
		
	}
	public void addObject(Actor a) {
	
	}

	public void addObject(Director d) {
		
	}

	public void addObject(Producer p) {
		
	}
	
	//Create methods to replace objects in the Model
	public void replaceObject(Movie m, Movie old) {
		
	}
	
	public void replaceObject(Series s, Series old) {
		
	}
	
	public void replaceObject(Episode e, Episode old) {
		
	}
	
	public void replaceObject(Actor a, Actor old) {
		
	}
	
	public void replaceObject(Director d, Director old) {
		
	}
	
	public void replaceObject(Producer p, Producer old) {
		
	}

	/**
	 * This method clears all data from the model, setting all class
	 * lists to null/empty, and notifying listeners
	 */
	public void clearAll() {
		
	}

	/**
	 * This method clears the specified categories list in the model, and notifying listeners
	 * 
	 * @param category		Type of list to cleared
	 */
	public void clear(String category) {

	}

	//Create various delete methods for each type of object
	public void deleteObject(Media obj) {

	}

	public void deleteObject(Movie obj) {
		
	}

	public void deleteObject(Series obj) {
		
	}

	public void deleteObject(Episode obj) {
		
	}

	public void deleteObject(MediaMaker obj) {
		
	}

	public void deleteObject(Actor obj) {
		
	}

	public void deleteObject(Director obj) {
	
	}

	public void deleteObject(Producer obj) {
		
	}
	
	
	//Create edit methods for different types of objects
	public void editObject(Media obj) {
		
	}

	public void editObject(MediaMaker obj) {
		
	}
	
	public void editObject(Movie m) {
		
	}

	//Create methods to return the various lists
	public ArrayList<Media> getMediaObjects() {

	}

	public ArrayList<Media> getMovieObjects() {

	}

	public ArrayList<Media> getSeriesObjects() {

	}

	public ArrayList<Media> getEpisodeObjects() {

	}

	public ArrayList<MediaMaker> getMediaMakerObjects() {
		
	}

	public ArrayList<MediaMaker> getActorObjects() {

	}

	public ArrayList<MediaMaker> getDirectorObjects() {

	}

	public ArrayList<MediaMaker> getProducerObjects() {

	}
	
	public void saveTxt(File file) throws IOException {
		
	}
	
	public void saveBinary(File file) throws IOException {
	
	}
	
	public static MediaModel readModel(File file) throws IOException, ClassNotFoundException {
		
	}

	/**
	 * This method adds the specified listener to the models ActionListener list
	 * 
	 * @param listener		ActionListener to add
	 */
	public synchronized void addActionListener(ActionListener listener) {
		
	}

	/**
	 * This methods removes the specified ActionLister from the ActionListener List
	 * @param listener
	 */
	public synchronized void removeActionListener(ActionListener listener) {
		
	}

	@SuppressWarnings("unchecked")
	private void processEvent(ActionEvent event) {
		
	}

	public char[] getListeners() {
		
	}
}
