import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class AddView extends JFrame implements ActionListener
{
	private static final long serialVersionUID = 1L;
	
	JButton jbtAdd = new JButton("Add");
	
	JTextField jtfTitle;
	JLabel jlTitle;
	JTextField jtfSeriesTitle;
	JLabel jlSeriesTitle;
	JTextField jtfReleaseYear;
	JLabel jlReleaseYear;
	JTextField jtfReleaseFormat;
	JLabel jlReleaseFormat;
	
	JTextField jtfStartYear;
	JLabel jlStartYear;
	JTextField jtfEndYear;
	JLabel jlEndYear;
	
	JTextField jtfEpisodeNumber;
	JLabel jlEpisodeNumber;
	JTextField jtfSeriesNumber;
	JLabel jlSeriesNumber;
	
	JTextField jtfName;
	JLabel jlName;
	
	JList<Movie> movieDisplay;
	JList<Episode> episodeDisplay;
	JScrollPane movieScroller;
	JScrollPane episodeScroller;
	
	/**
	 * This is the base constructor for AddView objects
	 */
	public AddView() {
		
	}
	
	/**
	 * This is the main constructor for media based objects, creating
	 * an addview depending on the int being passed in for Movie, Series, and 
	 * Episode Objects
	 * 
	 * @param typeBeingAdded		Type of object being added
	 */
	public AddView(int typeBeingAdded)
	{
		
	}
	
	/**
	 * This is the main constructor for MediaMaker based objects, detemined by the int
	 * passed in for Actor, Director, Producer
	 * 
	 * @param type					Type of object being added
	 * @param moviesToPick			Movies to add to the MediaMaker
	 * @param episodesToPick		Episodes to add to the MediaMaker
	 */
	public AddView(int type, ArrayList<Media> moviesToPick, ArrayList<Media> episodesToPick) {
		
	}
	
	public void addAddButtonListener(ActionListener addEpisodeListener) {

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
	}

}
