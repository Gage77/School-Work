import java.awt.CardLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collection;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;

public class SelectionView extends JFrame implements ActionListener{
	
	/** Default generated serialVersionUID */
	static final long serialVersionUID = 1L;

	/** This is the model that this selectionView can access to get information */
	MediaModel model;

	/** This list will display Media objects such as Movie, Series, Episode */
	DefaultListModel<Media> listModelMedia = new DefaultListModel<Media>();
	JList<Media> jlMedia = new JList<Media>(listModelMedia);

	/** This list will display MediaMaker objects such as Actor, Director, Producer */
	DefaultListModel<MediaMaker> listModelMakers = new DefaultListModel<MediaMaker>();
	JList<MediaMaker> jlMediaMaker = new JList<MediaMaker>(listModelMakers);

	/** Empty list */
	DefaultListModel<String> noData = new DefaultListModel<String>();
	JList<String> jlNoData = new JList<String>(noData);

	/** Radio button for Media Objects */
	JRadioButton jrbMedia = new JRadioButton("Media");
	/** Radio button for Movie Objects */
	JRadioButton jrbMovies = new JRadioButton("Movies");
	/** Radio button for Series Objects */
	JRadioButton jrbSeries = new JRadioButton("Series");
	/** Radio button for Episode Objects */
	JRadioButton jrbEpisodes = new JRadioButton("Episodes");
	/** Radio button for MediaMaker Objects */
	JRadioButton jrbMakers = new JRadioButton("Makers");
	/** Radio button for Actor Objects */
	JRadioButton jrbActors = new JRadioButton("Actors");
	/** Radio button for Director Objects */
	JRadioButton jrbDirectors = new JRadioButton("Directors");
	/** Radio button for Producer Objects */
	JRadioButton jrbProducers = new JRadioButton("Producers");
	
	/** 'File', 'Edit', and 'Display' menu */
	JMenu fileMenu = new JMenu("File");
	JMenu editMenu = new JMenu("Edit");
	JMenu displayMenu = new JMenu("Display");

	/** JMenuItems for 'File' menu */
	JMenuItem jmiLoad = new JMenuItem("Load");
	JMenuItem jmiSave = new JMenuItem("Save");
	JMenuItem jmiImport = new JMenuItem("Import");
	JMenuItem jmiExport = new JMenuItem("Export");

	/** JMenuItems for 'Edit' menu */
	JMenuItem jmiAdd = new JMenuItem("Add");
	JMenuItem jmiEdit = new JMenuItem("Edit");
	JMenuItem jmiDelete = new JMenuItem("Delete");
	JMenuItem jmiClear = new JMenuItem("Clear");
	JMenuItem jmiClearAll = new JMenuItem("Clear All");

	/** JMenuItems for 'Display' menu */
	JMenuItem jmiPieChart = new JMenuItem("Pie Chart");
	JMenuItem jmiHistogram = new JMenuItem("Histogram");
	JMenuItem jmiDoS = new JMenuItem("Degrees of Seperation");

	/** This will hold all of the JMenu objects */
	JMenuBar menuBar = new JMenuBar();

	/** Scroll panes that will contain JLists to display info */
	JScrollPane scrollPaneStart, scrollPaneMedia, scrollPaneMediaMaker;

	/** Split pane which will hold radio buttons on the left and scroll panes on the right */
	JSplitPane splitPane;

	/** JPanels for the buttons and scrollpanes */
	JPanel buttonList, scrollPanes;

	/** Group for radio buttons to ensure 1 button being pushed at one time */
	ButtonGroup buttons;

	/**
	 * This is the main constructor for the SelectionView object
	 */
	public SelectionView() {
		
	}

	/**
	 * This method sets the model for this SelectionView
	 * 
	 * @param model		MediaModel to set
	 */
	public void setModel(MediaModel model) {
		
	}

	/**
	 * This method re-fires all selected buttons
	 */
	public void refireSelectedButton() {

	}

	/**
	 * This method adds specified objects to the MediaMaker JList that is being displayed to the user,
	 * determined by the radio buttons
	 * 
	 * @param makers		MediaMakers to populate list with
	 */
	public void populateList(Collection<MediaMaker> makers) {
		
	}

	/**
	 * This method adds specified objects to the Media JLIst that is being displayed to the user,
	 * determined by the radio buttons
	 * 
	 * @param media			Media to populate list with
	 */
	public void populateList(ArrayList<Media> media) {
		
	}

	/**
	 * Action performed method. Performs specified action
	 */
	public void actionPerformed(ActionEvent actionEvent) {
	
	}
	
	// Create addListener methods for all of the radio buttons
	public void addMediaButtonListener(ActionListener addMediaListener) {

	}

	public void addMoviesButtonListener(ActionListener addMoviesListener) {

	}

	public void addSeriesButtonListener(ActionListener addSeriesListener) {

	}

	public void addEpisodeButtonListener(ActionListener addEpisodesListener) {

	}

	public void addMakersButtonListener(ActionListener addMakersListener) {

	}

	public void addActorsButtonListener(ActionListener addActorsListener) {

	}

	public void addDirectorsButtonListener(ActionListener addDirectorsListener) {

	}

	public void addProducersButtonListener(ActionListener addProducersListener) {

	}

	// Create addListener methods for the menu items in jmFile
	public void addLoadButtonListener(ActionListener addLoadListener) {

	}

	public void addSaveButtonListener(ActionListener addSaveListener) {

	}

	public void addImportButtonListener(ActionListener addImportListener) {

	}

	public void addExportButtonListener(ActionListener addExportListener) {

	}

	// Create addListener methods for the menu items in jmEdit
	public void addAddButtonListener(ActionListener addAddListener) {

	}

	public void addEditButtonListener(ActionListener addEditListener) {

	}

	public void addDeleteButtonListener(ActionListener addDeleteListener) {

	}

	public void addClearButtonListener(ActionListener addClearListener) {

	}

	public void addClearAllButtonListener(ActionListener addClearAllListener) {

	}

	// Create addListener methods for the menu items in jmDisplay
	public void addPieChartButtonListener(ActionListener addPieChartListener) {

	}

	public void addHistogramButtonListener(ActionListener addHistogramListener) {

	}
	
	public void addDoSButtonListener(ActionListener addDoSListener) {

	}
	

}