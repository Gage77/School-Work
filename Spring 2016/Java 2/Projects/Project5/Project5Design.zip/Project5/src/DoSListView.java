import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class DoSListView extends JFrame implements ActionListener {

	MediaModel model;
	JList displayList;
	JScrollPane displayScroller;
	
	/**
	 * Base constructor for DoSListView objects
	 */
	public DoSListView() {
		
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
	}

}
