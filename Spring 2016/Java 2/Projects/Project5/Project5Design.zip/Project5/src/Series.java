
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Series extends Media {
	private Integer endYear;
	private List<Media> episodes;

	/**
	 * This is the main constructor for Series objects
	 * 
	 * @param title			Title of the Series
	 * @param startYear		Year the Series first aired
	 * @param endYear		Year the Series last aired
	 */
	public Series(String title, Integer startYear, Integer endYear) {
		
	}

	/**
	 * Another constructor for Series objects
	 * 
	 * @param seriesTitle	Title of the Series
	 * @param startyear		Year the Series first aired
	 * @param endyear2		Year the Series last aired
	 * @param episodeList	List of Episode objects associated to this Series
	 */
	public Series(String seriesTitle, Integer startyear, Integer endyear2, ArrayList<Episode> episodeList) {
		
	}

	/**
	 * This method adds the specified Episode object to the Series's 
	 * list of Episodes
	 * 
	 * @param obj			Episode to add
	 */
	public void addEpisode(Episode obj) {

	}

	/**
	 * Returns the EndYear of this Series
	 * 
	 * @return				The EndYear of the Series	
	 */
	public Integer getEndYear() {
		return null;
	}

	/**
	 * Returns the list of Episode objects associated with this Series
	 * 
	 * @return				The List of Episode objects
	 */
	public List<Media> getEpisodes() {
		return null;
	}

	/**
	 * Returns the type of Media this is (Series)
	 */
	@Override
	public String getMediaType() {

	}

	/**
	 * Returns a string representation of the Series object
	 *
	 * @return				String representation of the Series object
	 */
	public String toString() {
		
	}
}