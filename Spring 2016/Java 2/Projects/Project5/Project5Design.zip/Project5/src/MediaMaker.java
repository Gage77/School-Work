import java.util.ArrayList;

public class MediaMaker {
	private String name;
	private String makerType;
	private ArrayList<Media> credits;

	/**
	 * This is the main constructor for MediaMaker objects
	 * 
	 * @param name			The name of the MediaMaker
	 */
	MediaMaker(String name) {
		
	}

	/**
	 * This is the base constructor fot MediaMaker objects
	 */
	public MediaMaker() {
		
	}

	/**
	 * This method sets the name of the MediaMaker object
	 * 
	 * @param name			The name to be set
	 */
	public void setName(String name) {

	}

	/**
	 * This method adds the specified credit to the MediaMaker
	 * object's list of credits 
	 * 
	 * @param obj			The Media object to add
	 */
	public void addCredit(Media obj) {

	}

	/**
	 * This method removes the specified Media object from the MediaMaker's
	 * credits
	 * 
	 * @param obj			The Media object to remove
	 */
	public void removeCredit(Media obj) {
	
	}

	/**
	 * This method returns the name of the MediaMaker
	 * 
	 * @return				Name of the MediaMaker
	 */
	public String getName() {
		return null;
	}

	/**
	 * This method returns the credits of the MediaMaker
	 * 
	 * @return				List of credits of the MediaMaker
	 */
	public ArrayList<Media> getCredits() {
		return null;
	}

	/**
	 * This method returns the type of the MediaMaker
	 * 
	 * @return				The type of MediaMaker
	 */
	public String getMakerType() {
		return null;
	}

	/**
	 * This method sets the MediaMaker's type
	 * 
	 * @param makerType		Type to set (Actor, Director, Producer)
	 */
	public void setMakerType(String makerType) {

	}
	
}