import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class EditView extends JFrame {

	private static final long serialVersionUID = 1L;
	
	JButton jbtCommenceEdit = new JButton("Commence Edit");
	
	JTextField jtfTitle;
	JLabel jlTitle;
	JTextField jtfSeriesTitle;
	JLabel jlSeriesTitle;
	JTextField jtfReleaseYear;
	JLabel jlReleaseYear;
	JTextField jtfReleaseFormat;
	JLabel jlReleaseFormat;
	
	JTextField jtfStartYear;
	JLabel jlStartYear;
	JTextField jtfEndYear;
	JLabel jlEndYear;
	
	JTextField jtfEpisodeNumber;
	JLabel jlEpisodeNumber;
	JTextField jtfSeriesNumber;
	JLabel jlSeriesNumber;
	
	JTextField jtfName;
	JLabel jlName;
	
	JList<Media> displayCredits;
	JScrollPane displayScroller;
	
	/**
	 * Base constructor for EditView objects
	 */
	public EditView() {
		
	}
	
	/**
	 * This is the main constructor for EditView objects involving
	 * media such as Movie, Series, or Episode
	 * 
	 * @param typeBeingEdited		Represents the type of object being edited
	 * @param selectedObject		The object to be edited
	 */
	public EditView(int typeBeingEdited, Media selectedObject) {	
		
	}
	
	/**
	 * This is the main constructor for EditView objects involving
	 * MediaMakers such as Actor, Director, or Producer
	 * 
	 * @param type					Represents the type of object being edited
	 * @param mediaMaker			The object to be edited
	 */
	public EditView(int type, MediaMaker mediaMaker) {
			
	}
	
	public void addEditButtonListener(ActionListener addEpisodeListener) {

	}

}
