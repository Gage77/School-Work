import java.util.Comparator;
import java.util.Iterator;
import java.util.List;


public class Media implements Comparable<Media> {
	/**
	 * Stores the title of a Media object. Can be accessed with the 'getTitle()'
	 * method.
	 */
	private String title;
	/**
	 * Stores the release year of a Media object. Can be accessed with the
	 * 'getReleaseYear()' method.
	 */
	private Integer releaseYear;
	/**
	 * Stores a list of all actors for a Media object.
	 */
	private List<String> actors;
	/**
	 * Stores a list of all directors for a Media object.
	 */
	private List<String> directors;
	/**
	 * Stores a list of all producers for a Media object.
	 */
	private List<String> producers;

	/**
	 * A constructor.
	 * 
	 * @param title
	 *            The title of a Media object.
	 */
	public Media(String title) {

	}

	/**
	 * A constructor
	 * 
	 * @param title
	 *            The title of a Media object.
	 * @param releaseYear
	 *            The year a Media object was released.
	 */

	public Media(String title, Integer releaseYear) {
	
	}

	/**
	 * Mutator method that adds an actors name to a Media objects list of
	 * actors.
	 * 
	 * @param name
	 *            The name of the actor.
	 */
	public void addActor(String name) {

	}

	/**
	 * Mutator method that adds a directors name to a Media objects list of
	 * directors.
	 * 
	 * @param name
	 *            The name of the director.
	 */
	public void addDirector(String name) {

	}

	/**
	 * Mutator method that adds a producers name to a Media objects list of
	 * producers.
	 * 
	 * @param name
	 *            The name of the producer.
	 */
	public void addProducer(String name) {

	}

	/**
	 * Allows a Media objects title to be accessed.
	 * 
	 * @return The media objects title.
	 */
	public String getTitle() {
		return null;
	}

	/**
	 * Allows a Media objects release year to be accessed.
	 * 
	 * @return The media objects release year.
	 */
	public Integer getReleaseYear() {
		return null;
	}

	/**
	 * Allows a Media objects list of actors to be accessed.
	 * 
	 * @return The media objects list of actors.
	 */
	public List<String> getActors() {
		return null;
	}

	/**
	 * Allows a Media objects list of directors to be accessed.
	 * 
	 * @return The media objects list of directors.
	 */
	public List<String> getDirectors() {
		return null;
	}

	/**
	 * Allows a Media objects list of producers to be accessed.
	 * 
	 * @return The media objects list of producers.
	 */
	public List<String> getProducers() {
		return null;
	}

	/**
	 * To be Overriden by Media subclasses. Allows the static List of Media
	 * objects to be seperated by media type.
	 * 
	 * @return Returns a string with the Media object's media type.
	 */
	public String getMediaType() {
		return null;
	}

	/**
	 * Ovewritten method. Should compare the title of Media Objects.
	 */
	@Override
	public int compareTo(Media arg0) {
		return null;
	}
	
}
	final class YearComparator implements Comparator<Media>{

		@Override
		public int compare(Media obj1, Media obj2) {
			return null;
		}}

