/**
 * Project #2 with Eclipse as the IDE
 * CS 2334, Section 013
 * 2/19/16
 * <P>
 * This class creates a simple media database system allowing 
 * users to search through a list of movies and TV episodes/series
 * </P>
 * @version 1.0
 */
public class Driver 
{
	/** Media database object holding Movies, Series, and Episodes */
	private Database mdb = new Database();
	
	/**
	 * Main method for the program, setting up interface for user to 
	 * search for media from provided database
	 * 
	 * @param args		Contains command line arguments
	 */
	public static void main(String[] args)
	{
		
	}

}
