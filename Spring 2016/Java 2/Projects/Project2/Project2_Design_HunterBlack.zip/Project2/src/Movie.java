/**
 * This class creates Movie objects from a file 
 * and allows the user to get various information
 * about that Movie
 */
public class Movie 
{
	/** Title of Movie */
	private String title;
	/** Year that the movie was released*/
	private String year;
	/** Format the Movie was released in (TV/V) */
	private String form;
	/** If two Movies with the same title were released in the same
	 * year, they will be a multiple
	 */
	private String multiple;
	
	/**
	 * Constructor method for Movie objects
	 * takes in a String containing all information of 
	 * a movie, and sends it to a parser method
	 * 
	 * @param line		String containing all Movie information
	 */
	public Movie(String line)
	{
		
	}
	
	/**
	 * Parser method that takes in Movie information
	 * and parses it to its corrective class variable,
	 * i.e. title, year, form, multiple
	 * 
	 * @param line		String containing all Movie information
	 */
	private void parseLine(String line)
	{
		
	}
	
	/**
	 * Returns the title of the Movie
	 * 
	 * @return		The title of the Movie (String)
	 */
	public String getTitle()
	{
		return null;
	}
	
	/**
	 * Returns the release year of the Movie
	 * 
	 * @return		The year of the Movie (String)
	 */
	public String getYear()
	{
		return null;
	}
	
	/**
	 * Returns the format that the Movie was released in (TV/V)
	 * 
	 * @return		The release format of the Movie (String)
	 */
	public String getForm()
	{
		return null;
	}
	
	/**
	 * Returns the multiple of the Movie if a Movie with the
	 * same title was released in the same year
	 * 
	 * @return		The multiple number of the Movie, if applicable (String)
	 * 				Null if not a multiple
	 */
	public String getMult()
	{
		return null;
	}
	
	/**
	 * Converts the Movie's information into a comprehensible String
	 * 
	 * @return		The String representation of Movie information
	 * @override	toString
	 */
	public String toString()
	{
		return null;
	}
}
