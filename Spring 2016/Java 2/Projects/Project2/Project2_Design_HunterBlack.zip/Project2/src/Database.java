import java.util.ArrayList;

/**
 * This class creates Database objects containing
 * ArrayLists of type Movie, Series, and Episode
 */
public class Database 
{
	/** ArrayList containing Movie */
	private ArrayList<Movie> movies;
	/** ArrayList of Series */
	private ArrayList<Series> series;
	/** ArrayList of Episode */
	private ArrayList<Episode> episodes;
	
	/**
	 * Constructor method for Database objects
	 * initiating the class variables movies, series, and episodes
	 */
	public Database()
	{
		movies = new ArrayList<Movie>();
		series = new ArrayList<Series>();
		episodes = new ArrayList<Episode>();
	}
	
	/**
	 * Inserts a Movie object into movies 
	 * 
	 * @param m		Movie object to insert
	 */
	public void insertMovie(Movie m)
	{
		
	}
	
	/**
	 * Inserts a Series into series
	 * 
	 * @param s		Series object to insert
	 */
	public void insertSeries(Series s)
	{
		
	}
	
	/**
	 * Inserts an Episode into episodes
	 * 
	 * @param e		Episode to insert
	 */
	public void insertEpisode(Episode e)
	{
		
	}
	
	/**
	 * Searches through specified ArrayList movies, series, or episodes
	 * and finds matching results, printing to the consoles
	 * 
	 * @param searchType		int indicating whether your searching through
	 * 							movies, series, or episodes
	 * @param param				The parameter to search by
	 */
	public void printInfo(int searchType, String param)
	{
		
	}
}
