
public class Movie 
{
	
	private String title = "";
	private String year = "";
	private String form = "";
	private String multiple = "";
	
	/**
	 * Constructor for Movie Object
	 * 
	 * @param line line to be parsed by parseLine method
	 */
	public Movie(String line)
	{
		parseLine(line);
	}
	
	/**
	 * Receives line containing all movie info and
	 * parses it into appropriate variables, i.e.
	 * title, year, form, and multiple
	 * 
	 * @param line line from file to be parsed containing movie info
	 */
	public static String[] parseLine(String line)
	{
		//return type temporary to ensure that parseLine algorithm works correctly
		//will eventually be void, with parser setting each class variable directly
		return null;
	}
	
	/**
	 * Gets movie title
	 * 
	 * @return Returns title of movie
	 */
	public static String getTitle()
	{
		return null;
	}
	
	/**
	 * Gets movie release year
	 * 
	 * @return Returns release year of movie
	 */
	public static String getYear()
	{
		return null;
	}
	
	/**
	 * Gets movie format (TV/V/none)
	 * 
	 * @return Returns TV, V, or null if no special format
	 */
	public static String getForm()
	{
		return null;
	}
	
	/**
	 * Gets multiple number of movie if more than
	 * one movie with that title was released in that
	 * year
	 * 
	 * @return Returns int representation of Roman Numeral of movie
	 */
	public static String getMultiple()
	{
		return null;
	}
	
}
