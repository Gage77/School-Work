import static org.junit.Assert.*;

import org.junit.Test;

public class MovieTest 
{
	
	@Test
	public void testParseLine()
	{
		String testCase = "Star Wars: A New Hope (1977)       1977";
		Movie testMovie = new Movie(testCase);
		
		String[] movieInfo = testMovie.parseLine(testCase);
		String[] actual = {"Star Wars: A New Hope", "1997"};
		
		assertArrayEquals(actual, movieInfo);
	}

	@Test
	public void testGetTitle() 
	{
		String testCase = "Star Wars: A New Hope (1977)       1977";
		Movie testMovie = new Movie(testCase);
		
		assertEquals("Star Wars: A New Hope", testMovie.getTitle());
	}
	
	@Test
	public void testPrintInfo()
	{
		Movie testCase = new Movie("Star Wars: A New Hope (1977)       1977");
		String param = "Star Wars";
		Database list = new Database(1);
		
		//will need to change return type to test, then change back once tested
		
		assertEquals("Star Wars: A New Hope (1977)       1977", list.printInfo(param));
	}


}
