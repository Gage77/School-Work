import javax.swing.JOptionPane;

/**
 * This program will create a small version of IMDb, used to 
 * search for various forms of media and learn about them.
 * This program will focus on movies only.
 * 
 * @author Hunter
 *
 */

public class Main 
{
	
	private JOptionPane menu = new JOptionPane();

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		
		String fileName = args[0]; //movie file that will be added as a program arg
		
	}

}
