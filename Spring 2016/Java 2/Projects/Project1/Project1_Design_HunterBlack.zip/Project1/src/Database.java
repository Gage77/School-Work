import java.util.ArrayList;

public class Database 
{

	private ArrayList<Movie> list;
	
	/**
	 * Constructor creating Database Object of size size
	 * 
	 * @param size number of lines in file(number of slots list needs)
	 */
	public Database(int size)
	{
		
	}
	
	/**
	 * Adds Movie Object to Database's array list
	 * 
	 * @param movie Movie Object to be added to list
	 */
	public static void insertMovie(Movie movie)
	{
		
	}
	
	/**
	 * Searches through Database Object using specified parameter
	 * until movie(s) matching description are found, 
	 * then prints that info to the console
	 * 
	 * @param param Search parameter (title, year, TV/V)
	 */
	public static void printInfo(String param)
	{
		
	}
	
	
}
