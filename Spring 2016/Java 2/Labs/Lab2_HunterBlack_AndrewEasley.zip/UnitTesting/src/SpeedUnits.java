/*
 * Enum for representing all of the speed units we want to use in this lab.
 */

public enum SpeedUnits {
	METERSPERSECOND, MILESPERHOUR
}
