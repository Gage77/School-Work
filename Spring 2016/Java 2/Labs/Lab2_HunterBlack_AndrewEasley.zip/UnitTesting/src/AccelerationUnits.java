/*
 * Enum for representing all of the acceleration units we want to use in this lab.
 */
public enum AccelerationUnits {
	METERSPERSECONDPERSECOND, FEETPERSECONDPERSECOND
}
