/*
 * Enum for representing all of the time units we want to use in this lab.
 */
public enum TimeUnits {
	SECONDS, HOURS, DAYS
}
