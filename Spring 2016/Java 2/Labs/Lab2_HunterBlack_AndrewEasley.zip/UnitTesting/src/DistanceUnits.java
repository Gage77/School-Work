/*
 * Enum for representing all of the distance units we want to use in this lab.
 */
public enum DistanceUnits {
	METERS, FEET, MILES
}
