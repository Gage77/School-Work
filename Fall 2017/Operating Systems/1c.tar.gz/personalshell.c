#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#define MAX_BUFFER 1024			// max line buffer
#define MAX_ARGS 64			// max # args
#define SEPARATORS " \t\n"		// token separators
#define README "readme"			// help file name

struct shellstatus_st 
{			
	int foreground;			// foreground execution flag (wait or not wait on child)
	char * infile;			// input redirection flag and file
	char * outfile;			// output redirectoin flag & file
	char * outmode;			// output redirection mode
};

typedef struct shellstatus_st shellstatus;

extern char **environ;

void check4redirection(char **, shellstatus *);		// check command line for i/o redirection
void errmsg(char *, char *);				// error message print out
void execute(char **, shellstatus);			// execute command from arg array
FILE * redirected_op(shellstatus);			// return required o/p stream
void syserrmsg(char *, char *);				// system error message printout
void echoEnable(int echoOn);				// disables and enables echo for pause command
void check4wait(char **, shellstatus *);		// tells whether or not to wait on child process in fork or not

/******************************************************/

int main (int argc, char ** argv)
{
	FILE * ostream = stdout;			// redirected o/p stream
	char linebuf[MAX_BUFFER];			// line buffer
	char cwdbuf[MAX_BUFFER];			// cwd buffer
	char * args[MAX_ARGS];				// pointers to arg strings
	char ** arg;					// working pointer through args
	char * prompt = "==>";				// shell prompt
	char * readmepath;				// readme pathname
	shellstatus status;				// status structure
	int execargs;					// execute command in args flag
	int i;						// working index
	int j;						// secondary index

	FILE * fp;					// batchfile variable
	char * fileline = NULL;				// batchfile line
	size_t linelen = 0;				// length of batchfile line
	ssize_t readfileline;				// holds read line from batcfhile

	// get starting cwd to add to readme pathname
	
	if(!getcwd(cwdbuf, sizeof(cwdbuf)))		// read current working directory
	{
		syserrmsg("getcwd",NULL);
		cwdbuf[0] = 0;
	}
	strcat(cwdbuf,"/" README);			// make full readme pathname
	readmepath = strdup(cwdbuf);

	// check for batch file
	
	if (argv[1])
	{
		printf("Batch file input detected...checking for file existance...\n");
		if (access(argv[1], F_OK) != -1)	// batchfile exists
		{
			printf("Specified batch file exists. Executing batch file ...\n");
			fp = fopen(argv[1], "r");
			if (fp == NULL)
			{
				errmsg(argv[1], "error in opening batchfile.\n");
				exit(0);
			}

			while ((readfileline = getline(&fileline, &linelen, fp)) != -1)
			{
				arg = args;
				* arg++ = strtok(fileline, SEPARATORS);
				while ((*arg++ = strtok(NULL, SEPARATORS)));
				if (args[0])
				{
				execargs = TRUE;		// set default execute of args

				// check for i/o reditrection
				check4redirection(args, &status);
	
				// check for wait flag for forked process
				check4wait(args, &status);
				// get rid of & from args to avoid bugs
				j = 0;
				while (args[j])
				{
					if (!strcmp(args[j], "&"))
					{
						args[j] = NULL;
					}
					j++;
				}

				// check for internal/external commands


				// "cd" command
				if (!strcmp(args[0], "cd"))
				{
					if (!args[1])
					{
						if (getcwd(cwdbuf, sizeof(cwdbuf)))
							printf("%s\n", cwdbuf);
						else
							syserrmsg("retrieving cwd", NULL);
					}
					else
					{
						if (chdir(args[1]))
						{
							syserrmsg("change directory failed", NULL);
						}
						else
						{
							strcpy(cwdbuf, "PWD=");
							if ((getcwd(&cwdbuf[4], sizeof(cwdbuf)-4)))
							{
								if (putenv(strdup(cwdbuf)))
									syserrmsg("change of PWD environment variable failed", NULL);
							}
							else
							{
								syserrmsg("retrieving cwd", NULL);
							}
						}
					}
					execargs = FALSE;
				}

				// "clr" command
				else if (!strcmp(args[0], "clr"))
				{
					args[0] = "clear";
					args[1] = NULL;
				}

				// "dir" command
				else if (!strcmp(args[0], "dir"))
				{
					for (i = MAX_ARGS - 1; i > 1; i--)
						args[i] = args[i-1];
					args[0] = "ls";
					args[1] = "-al";
					if (!args[2]);
						args[2] = ".";
				}

				// "environ" command
				else if (!strcmp(args[0], "environ"))
				{
					ostream = redirected_op(status);
					char ** envstr = environ;
					while (*envstr)
						fprintf(ostream, "%s\n", *envstr++);
					if (ostream != stdout) fclose(ostream);
					execargs = FALSE;
				}

				// "echo" command
				else if (!strcmp(args[0], "echo"))
				{
					int i = 0;
					while (args[i])
					{
						printf("%s ", args[i]);

						i++;
					}	
					printf("\n");

					execargs = FALSE;
				}
		
				// "pause" command
				else if (!strcmp(args[0], "pause"))
				{
					printf("Press \"Enter\" to continue...\n");
					echoEnable(0);

					char enterKey = 0;
					while (enterKey != '\r' && enterKey != '\n')
					{
						enterKey = getchar();
					}

					echoEnable(1);

					execargs = FALSE;
				}

				// "help" command
				else if (!strcmp(args[0], "help"))
				{
					args[0] = "more";
					args[1] = readmepath;
					args[2] = NULL;
				}

				// "quit" command
				else if (!strcmp(args[0], "quit"))
				{
					break;
				}

				// else pass command to OS shell
				if (execargs)
					execute(args, status);
			}
			}

			fclose(fp);
			if (fileline)
				free(fileline);
			exit(0);
		}
		else		// batchfile does not exist
		{
			printf("Specified batch file does not exist. Exiting shell...\n");
			exit(0);
		}	
	}

	// keep reading input until "quit" command or eof of redirected input
	
	while (!feof(stdin))
	{
		// (re)initialise status structure
		status.foreground = TRUE;

		// set prompt
		if (getcwd(cwdbuf, sizeof(cwdbuf)))		// read current working directory
			printf("%s%s", cwdbuf, prompt);		// output as prompt
		else					
			printf("getcwd ERROR %s", prompt);
		fflush(stdout);

		// get command line from input
		if (fgets(linebuf, MAX_BUFFER, stdin))		// read a line
		{
			// tokenize the input into args array
			arg = args;
			* arg++ = strtok(linebuf,SEPARATORS);	// tokenize input
			while ((*arg++ = strtok(NULL,SEPARATORS)));	// last entry will be NULL

			if (args[0])		// if there's anything there
			{
				execargs = TRUE;	// set default execute of args

				// check for i/o redirection
				check4redirection(args, &status);
				
				// check for wait flag for fork process
				check4wait(args, &status);
				// get rid of & from command line to avoid bugs
				j = 0;
				while (args[j])
				{
					if(!strcmp(args[j], "&"))
					{
						args[j] = NULL;
					}
					j++;
				}

				// check for internal/external commands
				
				// "cd" command
				if (!strcmp(args[0], "cd"))
				{
					if (!args[1])		// no directory argument
					{
						if (getcwd(cwdbuf, sizeof(cwdbuf)))
							printf("%s\n", cwdbuf);		// print cwd
						else
							syserrmsg("retrieving cwd",NULL);
					}
					else
					{
						if (chdir(args[1]))		// else change directory
						{
							syserrmsg("change directory failed",NULL);
						}
						else
						{
							strcpy(cwdbuf, "PWD=");		// and set environment value
							if ((getcwd(&cwdbuf[4], sizeof(cwdbuf)-4)))
							{
								if(putenv(strdup(cwdbuf)))
									syserrmsg("change of PWD environment variable failed",NULL);
							}
							else
							{
								syserrmsg("retrieving cwd",NULL);
							}
						}
					}
					execargs = FALSE;		// no need for further exec
				}

				// "clr" command
				else if (!strcmp(args[0], "clr"))
				{
					args[0] = "clear";
					args[1] = NULL;
				}

				// "dir" command
				else if (!strcmp(args[0], "dir"))
				{
					for (i = MAX_ARGS - 1; i > 1; i--)
						args[i] = args[i-1];		// shunt arguments
					args[0] = "ls";
					args[1] = "-al";
					if (!args[2])		// if no arg set cwd
						args[2] = ".";
				}

				// "environ" command
				else if (!strcmp(args[0], "environ"))
				{
					ostream = redirected_op(status);
					char ** envstr = environ;
					while (*envstr)			// print out environement
						fprintf(ostream, "%s\n", *envstr++);
					if (ostream != stdout) fclose(ostream);
					execargs = FALSE;		// no need for further exec
				}
				
				// "echo" command
				else if (!strcmp(args[0], "echo"))
				{
					int i = 1;
					while (args[i])		// while there are more args
					{
						printf("%s ", args[i]);	// print them to the console
						i++;
					}
					printf("\n");			// print new line for readability
					execargs = FALSE;		// no need for further exec
				}

				// "pause" command
				else if (!strcmp(args[0], "pause"))
				{
					printf("Press \"Enter\" to continue...\n");	// prompt user to enter "enter" to continue with shell
					echoEnable(0);		// disable keyboard echo until "enter" is pressed

					char enterKey = 0;
					while (enterKey != '\r' && enterKey != '\n')
					{
						enterKey = getchar();
					}

					echoEnable(1);		// re-enable keyboard echo after "enter" is pressed
					execargs = FALSE;		// no need for further exec
				}

				// "help" command
				else if (!strcmp(args[0], "help"))
				{
					args[0] = "more";
					args[1] = readmepath;
					args[2] = NULL;			// Run execvp with more readmepath as the argument, thus opening readme
				}

				// "quit" command
				else if (!strcmp(args[0], "quit"))
				{
					break;
				}

				// else pass command on to OS shell
				if (execargs)
					execute(args, status);
			}
		}
	}
	return 0;
}

/****************************************************
 *
 * void check4redirection(char ** args, shellstatus *sstatus);
 *
 * check command line args for i/o redirection symbols
 * set flags etc in *sstatus as appropriate
 *
 * *************************************************/

void check4redirection(char ** args, shellstatus *sstatus)
{
	// set defaults
	sstatus->infile = NULL;	
	sstatus->outfile = NULL;
	sstatus->outmode = NULL;

	while (*args)
	{
		if (!strcmp(*args, "<"))		// input redirection
		{
			* args = NULL;			// delimit args
			if(*(++args))			// file exists and permission OK?
			{
				if(access(*args, F_OK))
				{
					errmsg(*args, "does not exist for i/p redirection.");
				}
				else if (access(*args, R_OK))
				{
					errmsg(*args, "is not readable for i/p redirection.");
				}
				else
				{
					sstatus->infile = *args;
				}
			}
			else
			{
				errmsg("no filename with i/p redirection symbol.", NULL);
				break;		// reached end of args
			}
		}
		else if (!strcmp(*args, ">") || !strcmp(*args, ">>"))
		{
			if (!strcmp(*args, ">"))	// simple output redirection
			{
				sstatus->outmode = "w";
			}
			else				// output redirection - append
			{
				sstatus->outmode = "a";
			}

			* args = NULL;		// delimit args
			if(*(++args))		// permissions OK?
			{
				if (!access(*args, W_OK) || access(*args, F_OK))
				{
					sstatus->outfile = *args;
				}
				else
				{
					errmsg(*args, "is not writable/creatable for o/p redirection.");
				}
			}
			else
			{
				errmsg("no filename with o/p redirection symbol.",NULL);
				break;
			}
		}
		args++;
	}	
}

/*********************************************
 *
 * void execute(char ** args, shellstatus sstatus);
 *
 * fork and exec the program and command line arguments in args
 * if foreground flag is TRUE, wait until pgm completes before returning
 *
 ********************************************/

void execute(char ** args, shellstatus sstatus)
{
	int status;
	pid_t child_pid;

	switch(child_pid = fork())
	{
		case -1:
			syserrmsg("fork",NULL);
			break;
		case 0:
			// execution in child process
			// i/o redirection
			if (sstatus.infile)
			{
				if (!freopen(sstatus.infile, "r", stdin))
					errmsg(sstatus.infile, "can't be opened for i/p redirection.");
			}
			// final exec of program
			execvp(args[0], args);
			syserrmsg("exec failed -", args[0]);
			exit(127);
	}

	// continued execution in parent process
	if (sstatus.foreground)
		waitpid(child_pid, &status, WUNTRACED);
}

/**********************************************
 *
 * FILE * redirected_op(shellstatus status)
 *
 * return o/p stream (redirected if necessary)
 *
 * *******************************************/

FILE * redirected_op(shellstatus status)
{
	FILE * ostream = stdout;

	if (status.outfile)
	{
		if (!(ostream = fopen(status.outfile, status.outmode)))
		{
			syserrmsg(status.outfile, "can't be open for o/p redirection.");
			ostream = stdout;
		}
	}
	return ostream;
}

/********************************************
 *
 * void errmsg(char * msg1, char * msg2);
 *
 * print an error message (or two) on stderr
 *
 * if msg2 is NULL only msg1 is printed
 * if msg1 is NULL only "ERROR: " is printed
 *
 * ****************************************/

void errmsg(char * msg1, char * msg2)
{
	fprintf(stderr, "ERROR: ");
	if (msg1)
		fprintf(stderr, "%s; ", msg1);
	if (msg2)
		fprintf(stderr, "%s; ", msg2);
	return;
	fprintf(stderr, "\n");
}

/******************************************
 *
 * void syserrmsg(char * msg1, char * msg2);
 *
 * print an error message (or two) on stderr followed by 
 * system error message
 *
 * if msg2 is NULL only msg1 and system message is printed
 * if msg1 is NULL only the system message is printed
 *
 * ***************************************/

void syserrmsg(char * msg1, char * msg2)
{
	errmsg(msg1, msg2);
	perror(NULL);
	return;
}

/*****************************************
 *
 * void echoEnable(int echoOn);
 *
 * turn terminal echo off and on depending on echoOn
 *
 * echoOn = 1 == enable echo
 * echoOn = 0 == disable echo
 *
 *****************************************/

void echoEnable(int echoOn)
{
	struct termios TermConf;

	tcgetattr(STDIN_FILENO, &TermConf);

	if (echoOn)		// enable keyboard echo
		TermConf.c_lflag |= (ICANON | ECHO);
	else			// disable keyboard echo
		TermConf.c_lflag &= ~(ICANON | ECHO);


	tcsetattr(STDIN_FILENO, TCSANOW, &TermConf);
}

/*****************************************
 *
 * void check4wait(int checkwait);
 *
 * check to determine if shell should wait on child process or not
 * when calling fork function by checking to see if the args has
 * & in it
 *
 * If & exists in args, return 0 (don't wait)
 * If & does NOT esist in args, return 1 (do wait)
 *
 * **************************************/
void check4wait(char ** args, shellstatus *status)
{
	int waitflag = 0;
	while (*args)
	{
		if (!strcmp(*args, "&"))
		{
			status->foreground = FALSE;		// don't wait
			waitflag = 1;
		}
		args++;
	}
	if (waitflag == 0)
		status->foreground = TRUE;		// wait
}

