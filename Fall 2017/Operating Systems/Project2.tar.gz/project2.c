#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <math.h>

#define MAX_BUFFER 1024

// will hold all iformation regarding a single process that has requested
// memory, including its ID, its starting lcoation in the memoryBlock, and
// the total amount of memory it is taking up
struct processNode
{
	int startingLocation;		// starting location of process
	char * processLabel;		// process label of node
	int numBytes;			// total memory allocation (in bytes)
	int memBlockID;			// associated ID in memoryBlock array
	int inUse;			// determines whether node is currently active
};

// will hold all information required mainly for the nextfit algorithm, as 
// that algorithm will need to return two values: the new number of nodes and
// the most recently added node's location
struct memInfo
{
	int numNodes;			// total number of processNodes created
	int previousalloc;		// holds index of previously allocated node
};

typedef int bool;
#define true 1
#define false 0

int release (char * processID, int memBlock[], struct processNode nodes[], int allocationSize, int numNodes);					// release specified process
void listAssigned (struct processNode nodes[], int allocationSize, int numNodes);								// list all assigned processes
void listAvailable (int memBlock[], int allocationSize, int numNodes);										// list all free memory
void findID (char * memID, int memBlock[], struct processNode nodes[], int allocationSize, int numNodes); 					// find a particular process

int bestfit (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes);		// best fit algorithm
int firstfit (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes);		// first fit algorithm
struct memInfo nextfit (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, struct memInfo meminfo);		// next fit algorithm
int buddy (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes);		// buddy system algorithm

int main(int argc, char ** argv)
{
	char * linebuf = NULL;		// buffer for lines in provided file
	size_t len = 0;			// for file reading - len of line
	ssize_t read;			// for file reading - return from getline
	char * args[MAX_BUFFER];	// buffer for args pulled from linebuf
	char ** arg;			// working pointer through args
	FILE * fp;			// will hold file read inf rom command args

	char * algorithm;		// holds chosen algorithm
	int allocationsize;		// holds memory allocation size from inpup
	struct memInfo meminfo;		// will hold total numNodes, and previously allocated process index
	int numNodesNoStruct = 0;	// holds total number of nodes when not using struct memInfo

	int status;			// status for forks (help)
	pid_t child_pid;		// pid for forks (help)
	
	// check for help command
	if (!strcmp(argv[1], "help"))
	{
		args[0] = "more";
		args[1] = "/projects/2/readme";
		args[2] = NULL;

		switch(child_pid = fork())
		{
			case -1:
				fprintf(stdout, "Error in accessing readme");
				break;
			case 0:
				execvp(args[0], args);
				exit(0);
		}
		waitpid(child_pid, &status, WUNTRACED);
		exit(0);
	}

	// error check command arguments
	// check for input arguments
	if (!argv[1])
	{
		fprintf(stdout, "Error: No arguments given for program. Exiting...\n");
		exit(0);
	}

	// check for correct # of arguments
	if (!argv[2] || !argv[3])
	{
		fprintf(stdout, "Error: Not enough arguments given.\nEnter \"./project2 help\" for readme.\nExiting...\n");
		exit(0);
	}

	// check for algorithm
	// BESTFIT
	if (!strcmp(argv[1], "BESTFIT"))
	{
		algorithm = "BESTFIT";
		printf("algorithm set to %s...\n", algorithm);
	}
	// FIRSTFIT
	else if (!strcmp(argv[1], "FIRSTFIT"))
	{
		algorithm = "FIRSTFIT";
		printf("algorithm set to %s...\n", algorithm);
	}
	// NEXTFIT
	else if (!strcmp(argv[1], "NEXTFIT"))
	{
		algorithm = "NEXTFIT";
		printf("algorithm set to %s...\n", algorithm);
	}
	// BUDDY
	else if (!strcmp(argv[1], "BUDDY"))
	{
		algorithm = "BUDDY";
		printf("algorithm set to %s...\n", algorithm);
	}
	// algorithm does not exist, exit
	else
	{
		printf("Error: Chosen algorithm does not exist.\nPlease choose correct algorithm.\nExiting...\n");
		exit(0);
	}

	// set allocation size from argv[2]
	// must first check to see if argv[2] is between 4 and 20
	allocationsize = atoi(argv[2]);
	if (allocationsize < pow(2, 4) || allocationsize > pow(2, 16))
	{
		printf("Error: Memory allocation is not within the desired range (2^4-2^16)...\nExiting...\n");
		exit(0);
	}
	printf("Memory allocation size set to %d...\n", allocationsize);
	
	// create arrays to hold allocated space, and ID's
	int memoryBlock[allocationsize];
	struct processNode nodes[allocationsize];
	meminfo.numNodes = 0;
	meminfo.previousalloc = -1;
	// initialize memoryBlock with -1, which will indicate free memory
	for (int i = 0; i < allocationsize; i++)
	{
		memoryBlock[i] = -1;
	}

	// check existance of given file
	// file exists, run commands in file
	if (access(argv[3], F_OK) != -1)
	{
		printf("file exists\n\n");
		int listvar = 0;		
		// open file
		fp = fopen(argv[3], "r");
		// check for null file
		if (fp == NULL)
		{
			printf("Error: opening file error...\nExiting...\n");
			exit(0);
		}

		while ((read = getline(&linebuf, &len, fp)) != -1)
		{
			if (linebuf[0] != '#')
			{
				printf("%s", linebuf);
				arg = args;
				* arg++ = strtok(linebuf, " ");
				while ((*arg++ = strtok(NULL, " ")));
				if (args[0])
				{
					// requesting memory
					if (!strcmp(args[0], "REQUEST"))
					{
						printf("Requesting %s for %s\n", args[2], args[1]);
						
						// allocate using first fit algorithm
						if (!strcmp(algorithm, "FIRSTFIT"))
						{
							numNodesNoStruct = firstfit(args[1], args[2], nodes, memoryBlock, allocationsize, numNodesNoStruct);
						}
						// allocate using best fit algorithm
						else if (!strcmp(algorithm, "BESTFIT"))
						{
							numNodesNoStruct = bestfit(args[1], args[2], nodes, memoryBlock, allocationsize, numNodesNoStruct);
						}
						// allocate using next fit algorithm
						else if (!strcmp(algorithm, "NEXTFIT"))
						{
							meminfo = nextfit(args[1], args[2], nodes, memoryBlock, allocationsize, meminfo);
							printf("number of nodes = %d", meminfo.numNodes);
						}
						// allocate using buddy system algorithm
						else if (!strcmp(algorithm, "BUDDY"))
						{
							numNodesNoStruct = buddy(args[1], args[2], nodes, memoryBlock, allocationsize, numNodesNoStruct);
						}
					}
					
					// releasing memory
					else if (!strcmp(args[0], "RELEASE"))
					{
						printf("Releasing memory %s", args[1]);
						numNodesNoStruct =  release(argv[1], memoryBlock, nodes, allocationsize, numNodesNoStruct);	
					}
					
					if (!strcmp(args[0], "LIST"))
					{
						// list assigned memory
						if (!strcmp(args[1], "ASSIGNED\n"))
						{
							printf("List assigned memory:\n");
							listAssigned(nodes, allocationsize, numNodesNoStruct);
						}
	
						// list available memory
						else if (!strcmp(args[1], "AVAILABLE\n"))
						{
							printf("List all available memory:\n");
							listAvailable(memoryBlock, allocationsize, numNodesNoStruct);
						}
					}

					// find specified process
					else if (!strcmp(args[0], "FIND"))
					{
						printf("Find process %s", args[1]);
						if (!strcmp(algorithm, "NEXTFIT"))
						{
							findID(args[1], memoryBlock, nodes, allocationsize, meminfo.numNodes);
						}
						else
						{
							findID(args[1], memoryBlock, nodes, allocationsize, numNodesNoStruct); 
						}
					}
				}

				printf("\n");
			}
		}

		fclose(fp);
		if (linebuf)
			free(linebuf);
		exit(0);
	}
	// file does not exist, exit
	else
	{
		fprintf(stdout, "Error: Specified file does not exist.\nExiting...\n");
		exit(0);
	}

	return 0;

}

/****************************************
 *
 * release memory
 *
 * this function will rlease the designated process,
 * freeing up its memory in memoryBlock. Will print
 * FREE A n x, where n is the amount of reclaimed
 * memory and x is the start relative address of the
 * released memory. Print FAIL RELEASE A on error.
 *
 * *************************************/

int release (char * processID, int memBlock[], struct processNode nodes[], int allocationSize, int numNodes)
{
	int nodeIndex = -1;
	int nodeSize = 0;
	// get rid of process node
	for (int i = 0; i < numNodes; i++)
	{
		if (!strcmp(nodes[i].processLabel, processID))
		{
			nodeIndex = nodes[i].startingLocation;
			nodeSize = nodes[i].numBytes;
		}	
	}

	if (nodeIndex != -1)
	{
		for (int i = nodeIndex; i < nodeSize; i++)
		{
			memBlock[i] = -1;
		}
		return numNodes -1;
	}

	
	return numNodes - 1;
}

/***************************************
 *
 * list available
 *
 * this function will list all of the currently
 * available memory in memoryBlock. (n1, x1) (n2, x2) 
 * where n is the amount available, and x is the
 * starting location. Print FULL if no assigned
 * blocks exist.
 *
 * ************************************/

void listAvailable (int memBlock[], int allocationSize, int numNodes)
{
	// initialize temp variables to hold free areas, including indices
	int availablemem = 0;
	int startingindex = -1;
	int endindex = 0;

	for (int i = 0; i < allocationSize; i++)
	{
		// if the next memblock is taken, and there is currently open memory in the availblemem
		if (memBlock[i+1] != -1 && startingindex != -1)
		{
			printf("(%d,%d)", availablemem, startingindex);
		}
		// incrememnt current availablemem if the current memBlock item is free (-1)
		if (memBlock[i] == -1)
		{
			// the first free spot after a block of assigned memory in memBlock
			if (startingindex == -1)
			{
				startingindex = i;
			}
			availablemem = availablemem + 1;
		}
		// memory block is taken
		else
		{
			startingindex = -1;
			availablemem = 0;
		}	
	}
}

/****************************************
 *
 * list assigned
 *
 * this function will list all of the currently
 * assigned memory in memoryBlock. Prints triplets
 * (A1, n1, x1), where A represents process labels,
 * n represents the number of allocated bytes for
 * that process, and x is the relative starting 
 * address of the process. Print NONE if there are
 * no assigned blocks.
 *
 * ************************************/

void listAssigned (struct processNode nodes[], int allocationSize, int numNodes)
{
	// if there are no processes assigned, print NONE
	if (numNodes <= 0)
	{
		printf("NONE");
		return;
	}
	printf("num nodes = %d\n", numNodes);
	// run through all current processes and print their label, total memory assigned, and starting index in memBlock
	for (int i = 0; i < numNodes; i++)
	{
		printf("(%s,%d,%d)\n", nodes[i].processLabel, nodes[i].numBytes, nodes[i].startingLocation);	
	}
}

/****************************************
 *
 * find process
 *
 * this function will locate the specified 
 * process and will print the tuple (A, n, x)
 * where A is the specified process, n is the
 * amount allocated by A, and x is the relative 
 * starting adress of the process A
 *
 * *************************************/

void findID (char * memID, int memBlock[], struct processNode nodes[], int allocationSize, int numNodes)
{
	if (numNodes <= 0)
	{
		printf("NO CURRENT PROCESSES --> FAIL FIND %s", memID);
		return;
	}
	for (int i = 0; i < numNodes; i++)
	{
		printf("%s", nodes[i].processLabel);
		if (!strcmp(nodes[i].processLabel, memID))
		{
			printf("(%s,%d,%d)", nodes[i].processLabel, nodes[i].numBytes, nodes[i].startingLocation);
			return;
		}
	}

	printf("FAIL FIND %s", memID);
}

/****************************************
 *
 * FIRST FIT
 *
 * Starts at beginning of memoryBlock and finds
 * the first available position that has enough
 * space for the request.
 *
 * *************************************/

int firstfit(char * requestedProcessID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes)
{
	// convert requestedMem to int
	int requestedmemory = atoi(requestedMem);
	// create running count of open spaces from current pointer in memBlock
	int runningMemCount = 0;
	// create temp memBlock index holder
	int memBlockIndex = -1;
	bool success = false;

	// run through memBlock to find open space
	for (int i = 0; i < allocationSize; i++)
	{
		// check for break condition (there is enough memory)
		// create new node if break condition met
		if (runningMemCount == requestedmemory)
		{
			for (int j = memBlockIndex; j < (memBlockIndex + requestedmemory); j++)
			{
				memBlock[j] = numNodes;
			}
			struct processNode newNode;
			newNode.processLabel = requestedProcessID;
			newNode.startingLocation = memBlockIndex;
			newNode.numBytes = requestedmemory;
			newNode.memBlockID = numNodes;
			newNode.inUse = 1;

			nodes[numNodes] = newNode;
			success = true;
			// break out of for loop and return to main
			break;
		}
		// if there is no currently tracked memBlock index, make it i
		// if memBlock[i] is empty, increase runningMemCount
		if (memBlock[i] == -1)
		{
			if (memBlockIndex == -1)
			{
				memBlockIndex = i;
			}
			runningMemCount++;
		}
		// else, reset runningMemCount and memBlockIndex
		else
		{
			memBlockIndex = -1;
			runningMemCount = 0;
		}
	}

	// print out allocation	if successfull
	if (success)
	{
		printf("ALLOCATED %s %d", requestedProcessID, requestedmemory);
		numNodes = numNodes + 1;
	}
	else
	{
		printf("FAIL REQUEST %s %d...", requestedProcessID, requestedmemory);
	}
	return numNodes;
}

/***************************************
 *
 * BEST FIT
 *
 * Runs through entire memoryBlock and finds the 
 * location that is closes in size to the requested 
 * memory.
 *
 * *************************************/

int bestfit (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes)
{
	// convert requestedMem to int
	int requestedmemory = atoi(requestedMem);
	// create running count of open spaces from current pointer in memBlock 
	int runningMemCount = 0;
	// create temp memBlock index holder 
	int memBlockIndex = -1;
	bool success = false;
	// used to compare requested memory with current memcount
	int comparemem = -1;		
	int compareIndex = -1;	

	// run through memBlock to find open space
	for (int i = 0; i < allocationSize; i++)
	{
		// if the next index is in the array and is not free
		if ((i + 1) < allocationSize)
		{
			// compare the current running memory with the stored comparison
			if ((memBlock[i + 1] != -1) && runningMemCount < requestedmemory)
			{
				// no comparison memory setup yet
				if (comparemem == -1)
				{
					// setup comparison and index
					comparemem = runningMemCount;
					compareIndex = memBlockIndex;
					success = true;
				}
				// if the new running count is closer to the requested mem than the comparison
				else if((requestedmemory - runningMemCount) < comparemem)
				{
					// set new comparison and index
					comparemem = runningMemCount;
					compareIndex = memBlockIndex;
					success = true;
				}
			}
		}
		// check if current memBlock is free
		else if (memBlock[i] == -1)
		{
			if (memBlockIndex == -1)
			{
				memBlockIndex = i;
			}
				
		}
		else
		{
			memBlockIndex = -1;
			runningMemCount = 0;
		}
	}

	// create new node and print allocation if successfull
	if (success)
	{
		for (int i = compareIndex; i < requestedmemory; i++)
		{
			memBlock[i] = numNodes;
		}

		struct processNode newNode;
		newNode.processLabel = processID;
		newNode.numBytes = requestedmemory;
		newNode.startingLocation = compareIndex;
		newNode.memBlockID = numNodes;
		newNode.inUse = 1;

		nodes[numNodes] = newNode;

		printf("ALLOCATED %s %d", processID, requestedmemory);

		numNodes = numNodes + 1;
	}
	// print failure if not able to allocate
	else
	{
		printf("FAIL REQUEST %s %d...", processID, requestedmemory);
	}

	return numNodes;
}

/***************************************
 *
 * NEXT FIT
 *
 * Starts at previously allocated spot, and finds
 * the next available space that fits the requested
 * memory.
 *
 * *************************************/

struct memInfo nextfit (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, struct memInfo meminfo)
{
	// convert requestedMem to int
	int requestedmemory = atoi(requestedMem);
	// create running count of open spaces from current point in memBlock
	int runningMemCount = 0;
	// create temp memBlock index holder
	int memBlockIndex = -1;
	bool success = false;
	bool noprev = false;
	int numNodes = meminfo.numNodes;

	// run through memBlock to find next open space starting at 0 if no previous allocation set
	if (meminfo.previousalloc == -1)
	{
		// check to ensure requested memory is not larger than total allocation size
		if (requestedmemory <= allocationSize)
		{
			for (int j = 0; j < requestedmemory; j++)
			{
				memBlock[j] = numNodes;
			}	
			struct processNode newNode;
			newNode.processLabel = processID;
			newNode.numBytes = requestedmemory;
			newNode.memBlockID = numNodes;
			newNode.startingLocation = 0;
			newNode.inUse = 1;

			nodes[0] = newNode;
			success = true;
			noprev = true;
		}	
	}

	// if previous allocation set, start at previous allocation
	else
	{
		// run from previous alloc to end of memblock
		for (int i = meminfo.previousalloc; i < allocationSize; i++)
		{
			// break condition, create node
			if (runningMemCount == requestedmemory)
			{
				for (int j = memBlockIndex; j < (memBlockIndex + requestedmemory); j++)
				{
					memBlock[j] = numNodes;
				}

				struct processNode newNode;
				newNode.processLabel = processID;
				newNode.numBytes = requestedmemory;
				newNode.memBlockID = numNodes;
				newNode.startingLocation = memBlockIndex;
				newNode.inUse = 1;
				
				nodes[numNodes] = newNode;
				success = true;
				break;
			}
			
			if (memBlock[i] == -1)
			{
				if (memBlockIndex == -1)
				{
					memBlockIndex = i;
				}
				runningMemCount++;
			}
			else
			{
				runningMemCount = 0;
				memBlockIndex = -1;
			}
		}

		// if a spot was not found in the above loop, go from beginning to previous alloc
		if (!success)
		{
			for (int i = 0; i < meminfo.previousalloc; i++)
			{
				// break condition
				if (runningMemCount == requestedmemory)
				{
					for (int j = memBlockIndex; j < (memBlockIndex + requestedmemory); j++)
					{
						memBlock[j] = numNodes;
					}

					struct processNode newNode;
					newNode.processLabel = processID;
					newNode.numBytes = requestedmemory;
					newNode.startingLocation = memBlockIndex;
					newNode.memBlockID = numNodes;
					newNode.inUse = 1;

					nodes[numNodes] = newNode;
					success = true;
					break;
				}

				// free space
				if (memBlock[i] == -1)
				{
					if (memBlockIndex == -1)
					{		
						memBlockIndex = i;
					}
					runningMemCount++;
				}
				// not free space
				else
				{
					memBlockIndex = -1;
					runningMemCount = 0;
				}
			}
		}
	}

	// print allocation if success
	if (success)
	{
		printf("ALLOCATED %s %d", processID, requestedmemory);
		meminfo.numNodes = numNodes + 1;
		if (noprev)
		{
			meminfo.previousalloc = 0;
		}
		else
		{
			meminfo.previousalloc = memBlockIndex;
		}
	}
	// if unsuccessfull in allocation, print error
	else
	{
		printf("FAIL REQUEST %s %d...", processID, requestedmemory);
	}

	return meminfo;
}

/***************************************
 *
 * BUDDY SYSTEM
 *
 * ASDG
 *
 * *************************************/

int buddy (char * processID, char * requestedMem, struct processNode nodes[], int memBlock[], int allocationSize, int numNodes)
{
	
}
