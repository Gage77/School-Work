
public class Project2_HunterBlack 
{
	public static void main(String[]args){
		
	//Hunter Blacks book choices and subsequent cost
		
		//Declared and initialized constants
		final double COST_GOT = 6.74; //Game of Thrones
		final int COST_WOT = 6; //Wheel of Time
		final double COST_DIVCOM = 23.99; //Dantes Divine Comedy
		final int GOT_AMOUNT = 2;
		final int WOT_AMOUNT = 3;
		final int DIVCOM_AMOUNT = 2;
		
		//Declared variables
		double saleTax;
		double costWithoutTax;  
		double subTotal;
		double totalCost; // cost including tax
		
		//Initialized variables
		saleTax = 0.065;
		costWithoutTax = 0.0;
		subTotal = 0.0;
		totalCost = 0.0;
		
		//Arithmetic
		costWithoutTax = (COST_GOT * GOT_AMOUNT) + (COST_WOT * WOT_AMOUNT) + (COST_DIVCOM * DIVCOM_AMOUNT);
		subTotal = costWithoutTax * saleTax;
		totalCost = costWithoutTax + subTotal;
		
		//Output to console
		System.out.println("The cost of the books without tax is $" + costWithoutTax + ".");
		System.out.println("The subTotal is $" + subTotal + ".");
		System.out.println("");
		System.out.println("The final cost is $" + totalCost + ".");
		
	}
	

}
