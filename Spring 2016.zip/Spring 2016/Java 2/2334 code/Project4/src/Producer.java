

public class Producer extends MediaMaker{

	public Producer(String name) {
		super(name);
		super.setMakerType("Producer");
	}
	
	public String toString() {
		String makerInfo = super.toString();
		return makerInfo;
	}

}