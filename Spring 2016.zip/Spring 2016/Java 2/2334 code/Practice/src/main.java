import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;

public class main 
{
	public static void main(String[] args) throws IOException 
	{
//		System.out.println("Enter the name of the text file");
//		Scanner inp = new Scanner(System.in);
//		String file = inp.nextLine();
//		
//		FileReader fr = new FileReader(file);
//		BufferedReader br = new BufferedReader(fr);
//		
//		ArrayList<String> names = new ArrayList<String>();
//		ArrayList<Actor> actors = new ArrayList<Actor>();
//		ArrayList<Movie> movies = new ArrayList<Movie>();
//		ArrayList<Series> seriesList = new ArrayList<Series>();
//		ArrayList<Episode> episodes = new ArrayList<Episode>();
//		
//		String line = "";
//		String name = "";
//		String tempName = "";
//		
//		String mediaInfo = "";
//								
//		while ((line = br.readLine()) != null)
//		{
//			
//			//Parse the name of the MediaMaker
//			String[] firstTabSplit = line.split("\t");
//			if (firstTabSplit[0].length() > 1) 
//			{
//				tempName = firstTabSplit[0];
//				String[] nameSplit = tempName.split(" ");
//				if (nameSplit.length == 2)
//				{
//					name = nameSplit[1];
//					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
//				}
//				else if (nameSplit.length == 3)
//				{
//					name = nameSplit[1];
//					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
//					name = name + " " + nameSplit[2];
//				}
//				else if (nameSplit.length == 4)
//				{
//					name = nameSplit[1];
//					name = name + " " + nameSplit[2];
//					name = name + " " + nameSplit[3];
//					name = name + " " + nameSplit[0].substring(0, nameSplit[0].length() - 1); //gets rid of the comma
//				}
//				//Adds the name to the overall name list if not already present, and then the actors list
//				if (!names.contains(name))
//				{
//					names.add(name);
//					actors.add(new Actor(name));
//				}
//				else if (names.contains(name))
//				{
//					actors.add(new Actor(name));
//				}
//				//System.out.println(name);
//			}
//			
//			mediaInfo = firstTabSplit[firstTabSplit.length - 1];
//			String[] mediaInfoSplit = mediaInfo.split(" ");
//			String title = "";
//			String releaseYear = "";
//			String venue = "";
//			
//			String seriesTitle = "";
//			String episodeTitle = "";
//			String episodeNumber = "";
//			
//			//New Movie to create and add to current MediaMaker
//			if (!mediaInfoSplit[0].contains("\""))
//			{
//				//get title of movie
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains(")"))
//					{
//						break;
//					}
//					else
//					{
//						title = title + " " + mediaInfoSplit[i];
//					}
//				}
//				//get release year of the movie
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].length() == 6)
//					{
//						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
//					}
//					else if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains("/"))
//					{
//						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
//					}
//				}
//				//get venue of the movie
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("(V)") || mediaInfoSplit[i].contains("(TV)"))
//					{
//						venue = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
//					}
//				}
//				
//				//Create new Movie object, and add it to the list of Movies if not already present, as well ass
//				//the current MediaMaker
//				Movie movie = new Movie(title, releaseYear, venue);
//				if (!movies.contains(movie))
//					movies.add(movie);
//				
//				if (names.contains(name))
//				{
//					for (int i = 0; i < actors.size(); ++i)
//					{
//						if (actors.get(i).getName().equals(name))
//							actors.get(i).addMovieCredit(movie);
//					}
//				}
//			}
//			
//			//New Episode to create and add to respective lists
//			else if (mediaInfoSplit[0].contains("\""))
//			{
//				//get the series title
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("("))
//						break;
//					else 
//						seriesTitle = seriesTitle + " " + mediaInfoSplit[i];
//				}
//				//get the release year for the series
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].length() == 6)
//					{
//						releaseYear = mediaInfoSplit[i].substring(1, mediaInfoSplit[i].length() - 1);
//					}
//				}
//				//get the episode title
//				int episodeTitleIndex = 0;
//				for (int i = 0; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("{"))
//						episodeTitleIndex = i;
//				}
//				for (int i = episodeTitleIndex; i < mediaInfoSplit.length; ++i)
//				{
//					if (mediaInfoSplit[i].contains("#") || (mediaInfoSplit[i].contains("(") && mediaInfoSplit[i].contains("-")))
//					{
//						episodeNumber = mediaInfoSplit[i];
//						break;
//					}
//					else if (mediaInfoSplit[i].contains("[") || mediaInfoSplit[i].contains("archive"))
//						break;
//					else
//					{
//						episodeTitle = episodeTitle + " " + mediaInfoSplit[i];
//					}
//				}
//				//fix up the title and number
//				episodeTitle = episodeTitle.replace("{", "");
//				episodeNumber = episodeNumber.replace("(", " ");
//				episodeNumber = episodeNumber.replace(")", " ");
//				episodeNumber = episodeNumber.replace("{", " ");
//				episodeNumber = episodeNumber.replace("}", " ");
//				
//				Series series = new Series(seriesTitle, releaseYear, null);
//				Episode episode = new Episode(episodeTitle, seriesTitle, episodeNumber, releaseYear);
//				
//				if (!seriesList.contains(series))
//				{
//					seriesList.add(series);
//				}
//				for (int i = 0; i < seriesList.size(); ++i)
//				{
//					if (seriesList.get(i).getTitle().equals(seriesTitle))
//					{
//						seriesList.get(i).addEpisode(episode);
//					}
//				}
//				if (!episodes.contains(episode))
//					episodes.add(episode);
//				if (names.contains(name))
//				{
//					for (int i = 0; i < actors.size(); ++i)
//					{
//						if (actors.get(i).getName().equals(name))
//							actors.get(i).addEpisodeCredit(episode);
//					}
//				}
//			}			
//			
//		}		
//		
//		
//		//Remove the null Movie that is created for all Actors
//		for (Actor a : actors)
//			a.removeMovieCredit(a.getMovieCredits().size() - 1);
//		
//		ArrayList<Episode> credits = actors.get(3).getEpisodeCredits();
//		for (int i = 0; i < credits.size(); ++i)
//			System.out.println(credits.get(i));
		
		PieChart chart = new PieChart("Pie Chart Example", "OS comparison");
		chart.pack();
		chart.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		chart.setVisible(true);
	}
}
