/**
 * Lab #2
 * CS 2334, Section *** INSERT YOUR LAB SECTION NUMBER HERE ***
 * *** THE CURRENT DATE GOES HERE ***
 * <P>
 * This is the driver class of Lab2. A good driver should be as concise 
 * as possible and contains only the main() method.
 * </P>
 * @version 1.0
 */

public class Lab2Driver {

	public static void main(String[] args) {

		Lab2 lab2Program;
		lab2Program = new Lab2(5);

	}

}
