import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 * Project #4 CS 2334, Section 013 4/13/16
 * <p>
 * This class will satisfy the controller portion of the MVC design plan
 * </p>
 * 
 * @version 1.0
 *
 */
public class MediaController {

	/** This will be the model that this controller is connected to */
	MediaModel model;
	
	/** This will be the selection view controller listens to and interacts with */
	private SelectionView slView;
	
	/** This will be the AddView that this controller listens and interacts with */
	private AddView addView;
	
	/** This will be the EditView that this controller listens and interacts with */
	private EditView editView;

	/**
	 * The base constructor for this object
	 */
	public MediaController() {

	}

	// Create private class listeners for the radio buttons
	private class AddMediaListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Media");

			slView.populateList(model.getMediaObjects());
		}
	}

	private class AddMoviesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Movies");

			slView.populateList(model.getMovieObjects());
		}
	}

	private class AddSeriesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Series");

			slView.populateList(model.getSeriesObjects());
		}
	}

	private class AddEpisodesListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Episodes");

			slView.populateList(model.getEpisodeObjects());
		}
	}

	private class AddMakersListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Makers");

			slView.populateList(model.getMediaMakerObjects());

		}
	}

	private class AddActorsListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Actors");

			slView.populateList(model.getActorObjects());

		}
	}

	private class AddDirectorsListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Directors");

			slView.populateList(model.getDirectorObjects());

		}
	}

	private class AddProducersListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Producers");
			
				slView.populateList(model.getProducerObjects());
		}	
	}

	// Create private classes for the JMenu jmFile
	private class AddSaveListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			File chosenFile;
			JFileChooser fc = new JFileChooser();
			int returnValue = fc.showSaveDialog(fc);
			if (returnValue == JFileChooser.APPROVE_OPTION)
			{
				chosenFile = fc.getSelectedFile();
				try {
					model.saveTxt(chosenFile);
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(null, "Error in saving to specified file, please try again");
					e1.printStackTrace();
				}
			}
						
			System.out.println("Save");
		}
	}

	private class AddLoadListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			File chosenFile;
			JFileChooser fc = new JFileChooser();
			int returnValue = fc.showOpenDialog(fc);
			if (returnValue == JFileChooser.APPROVE_OPTION)
			{
				chosenFile = fc.getSelectedFile();
				try {
					MediaModel newModel = MediaModel.readModel(chosenFile);
					setModel(newModel);
					
				} catch (ClassNotFoundException | IOException e1) {
					JOptionPane.showMessageDialog(null, "Error reading from binary file. Please try again or choose a different file.");
					e1.printStackTrace();
				}
			}
			
			System.out.println("Load");
			
		}
	}

	private class AddImportListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Object[] options = {"Movies", "Series/Episode", "Actors", "Directors", "Producers"};
			String s = (String)JOptionPane.showInputDialog(null, "Choose the type of objects represented in the selected file",
					"File type", JOptionPane.QUESTION_MESSAGE, null, options, "Movies");
			File chosenFile;
			JFileChooser fc = new JFileChooser();
			int returnValue = fc.showOpenDialog(fc);
			if (returnValue == JFileChooser.APPROVE_OPTION)
			{
				chosenFile = fc.getSelectedFile();
				model.parseSelectedFile(chosenFile, s);
			}
			System.out.println("Import");
		}	
	}

	private class AddExportListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			File chosenFile;
			JFileChooser fc = new JFileChooser();
			int returnValue = fc.showOpenDialog(fc);
			if (returnValue == JFileChooser.APPROVE_OPTION);
			{
				chosenFile = fc.getSelectedFile();
				try {
					model.saveBinary(chosenFile);
				} catch (IOException e1) {
					System.out.println("error in saving binary");
				}
			}
			System.out.println("Export");
		}
	}

	// Create the private class listeners for the JMenu jmEdit
	private class AddAddListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (slView.jrbMovies.isSelected())
			{
				AddView movieAddView = new AddView(1);
				setAddView(movieAddView);
				
			}
			else if (slView.jrbSeries.isSelected())
			{
				AddView seriesAddView = new AddView(2);
				setAddView(seriesAddView);
			}
			else if (slView.jrbEpisodes.isSelected())
			{
				AddView episodeAddView = new AddView(3);
				setAddView(episodeAddView);
			}
			else if (slView.jrbActors.isSelected())
			{
				AddView actorsAddView = new AddView(4, model.getMovieObjects(), model.getEpisodeObjects());
				setAddView(actorsAddView);
			}
			else if (slView.jrbDirectors.isSelected())
			{
				AddView directorsAddView = new AddView(4, model.getMovieObjects(), model.getEpisodeObjects());
				setAddView(directorsAddView);
			}
			else if (slView.jrbProducers.isSelected())
			{
				AddView producersAddView = new AddView(4, model.getMovieObjects(), model.getEpisodeObjects());
				setAddView(producersAddView);
			}
			
			System.out.println("Add");
		}		
	}

	
	private class AddAddButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			boolean flag = false; //This will indicate whether the object already exists in the model
			//First if statement will deal with Movies being dealt with
			if (slView.jrbMovies.isSelected())
			{
				String title = addView.jtfTitle.getText();
				Integer releaseYear = Integer.valueOf(addView.jtfReleaseYear.getText());
				String releaseFormat = addView.jtfReleaseFormat.getText();
				
				Movie movie = new Movie(title, releaseYear, releaseFormat);

				if (flag == false)
				{
					model.addObject(movie);
				}
			}
			//Second if statement deals with Series being dealt with
			else if (slView.jrbSeries.isSelected())
			{
				String title = addView.jtfTitle.getText();
				Integer startYear = Integer.valueOf(addView.jtfStartYear.getText());
				Integer endYear = Integer.valueOf(addView.jtfEndYear.getText());
				
				Series series = new Series(title, startYear, endYear);

				if (flag == false)
				{
					model.addObject(series);
				}
			}
			//Third if statement will deal with Episode objects
			else if (slView.jrbEpisodes.isSelected())
			{
				String episodeTitle = addView.jtfTitle.getText();
				Integer episodeNumber = Integer.valueOf(addView.jtfEpisodeNumber.getText());
				Integer releaseYear = Integer.valueOf(addView.jtfReleaseYear.getText());
				String seriesTitle = addView.jtfSeriesTitle.getText();
				
				Episode episode = new Episode(episodeTitle, releaseYear, seriesTitle, episodeNumber);

				if (flag == false)
				{
					model.addObject(episode);
				}
			}
			//Deals with adding Actor objects
			else if (slView.jrbActors.isSelected())
			{
				String name = addView.jtfName.getText();
				
				Actor actor = new Actor(name);

				if (!addView.movieDisplay.isSelectionEmpty())
				{
					ArrayList<Movie> selectedMovies = (ArrayList<Movie>)addView.movieDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedMovies.size(); ++i)
					{
						actor.addCredit(selectedMovies.get(i));
					}
				}
				if (!addView.episodeDisplay.isSelectionEmpty())
				{
					ArrayList<Episode> selectedEpisodes = (ArrayList<Episode>)addView.episodeDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedEpisodes.size(); ++i)
					{
						actor.addCredit(selectedEpisodes.get(i));
					}
				}
						
				model.addObject(actor);
			}
			//Deals with adding Director objects
			else if (slView.jrbDirectors.isSelected())
			{
				String name = addView.jtfName.getText();
				
				Director director = new Director(name);
				
				if (!addView.movieDisplay.isSelectionEmpty())
				{
					ArrayList<Movie> selectedMovies = (ArrayList<Movie>)addView.movieDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedMovies.size(); ++i)
					{
						director.addCredit(selectedMovies.get(i));
					}
				}
				if (!addView.episodeDisplay.isSelectionEmpty())
				{
					ArrayList<Episode> selectedEpisodes = (ArrayList<Episode>)addView.episodeDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedEpisodes.size(); ++i)
					{
						director.addCredit(selectedEpisodes.get(i));
					}
				}
						
				model.addObject(director);
			}
			//Deals with adding producer objects
			else if (slView.jrbProducers.isSelected())
			{
				String name = addView.jtfName.getText();
				
				Producer producer = new Producer(name);
				
				if (!addView.movieDisplay.isSelectionEmpty())
				{
					ArrayList<Movie> selectedMovies = (ArrayList<Movie>)addView.movieDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedMovies.size(); ++i)
					{
						producer.addCredit(selectedMovies.get(i));
					}
				}
				if (!addView.episodeDisplay.isSelectionEmpty())
				{
					ArrayList<Episode> selectedEpisodes = (ArrayList<Episode>)addView.episodeDisplay.getSelectedValuesList();
					for (int i = 0; i < selectedEpisodes.size(); ++i)
					{
						producer.addCredit(selectedEpisodes.get(i));
					}
				}
						
				model.addObject(producer);
			}
		}
	}
	

	private class AddEditListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (slView.jrbMovies.isSelected())
			{
				EditView movieEditView = new EditView(1, slView.jlMedia.getSelectedValue());
				setEditView(movieEditView);
			}
			else if (slView.jrbSeries.isSelected()) 
			{
				EditView seriesEditView = new EditView(2, slView.jlMedia.getSelectedValue());
				setEditView(seriesEditView);
			}
			else if (slView.jrbEpisodes.isSelected()) 
			{
				EditView episodeEditView = new EditView(3, slView.jlMedia.getSelectedValue());
				setEditView(episodeEditView);
			}
			else if (slView.jrbActors.isSelected())
			{
				EditView actorEditView = new EditView(1, slView.jlMediaMaker.getSelectedValue());
				setEditView(actorEditView);
			}
			else if (slView.jrbDirectors.isSelected())
			{
				EditView directorEditView = new EditView(2, slView.jlMediaMaker.getSelectedValue());
				setEditView(directorEditView);
			}
			else if (slView.jrbProducers.isSelected())
			{
				EditView producerEditView = new EditView(3, slView.jlMediaMaker.getSelectedValue());
				setEditView(producerEditView);
			}
			else if (slView.jrbMedia.isSelected() || slView.jrbMakers.isSelected())
			{
				JOptionPane.showMessageDialog(null, "Please choose the button of the specific type of object being edited");
			}
			System.out.println("Edit");
		}
	}
	
	private class AddEditButtonListener implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (slView.jrbMovies.isSelected())
			{
				String title = editView.jtfTitle.getText();
				Integer releaseYear = Integer.valueOf(editView.jtfReleaseYear.getText());
				String venue = editView.jtfReleaseFormat.getText();
				
				Movie movie = new Movie(title, releaseYear, venue);
				
				model.replaceObject(movie, (Movie)slView.jlMedia.getSelectedValue());
			}
			else if (slView.jrbSeries.isSelected())
			{
				String title = editView.jtfTitle.getText();
				Integer startYear = Integer.valueOf(editView.jtfReleaseYear.getText());
				Integer endYear = Integer.valueOf(editView.jtfEndYear.getText());
				
				Series series = new Series(title, startYear, endYear);
				
				model.replaceObject(series, (Series)slView.jlMedia.getSelectedValue());
			}
			else if (slView.jrbEpisodes.isSelected())
			{
				String episodeTitle = editView.jtfTitle.getText();
				Integer episodeNumber = Integer.valueOf(editView.jtfEpisodeNumber.getText());
				Integer releaseYear = Integer.valueOf(editView.jtfReleaseYear.getText());
				String seriesTitle = editView.jtfSeriesTitle.getText();
				
				Episode episode = new Episode(episodeTitle, releaseYear, seriesTitle, episodeNumber);
				
				model.replaceObject(episode, (Episode)slView.jlMedia.getSelectedValue());
			}
			System.out.println("Edit button pushed");
			
		}
	}

	private class AddDeleteListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Delete"); //Tests if button click recognized.
			System.out.println(model.getMediaMakerObjects());//Tests model preconditions.
			model.getListeners();
			if (slView.jrbMedia.isSelected()) {
				for (Media a : slView.jlMedia.getSelectedValuesList()) {
					model.deleteObject(a);
				}
			}
			else if (slView.jrbMovies.isSelected()){
				for (Media m : slView.jlMedia.getSelectedValuesList()) {
					model.deleteObject((Movie)m);
				}
			}
			else if (slView.jrbSeries.isSelected()){
				for (Media s : slView.jlMedia.getSelectedValuesList()) {
					model.deleteObject((Series)s);
				}
			}
			else if (slView.jrbEpisodes.isSelected()) {
				for (Media ep : slView.jlMedia.getSelectedValuesList()) {
					model.deleteObject((Episode)ep);
				}
			}

			if (slView.jrbMakers.isSelected()) {
				for (MediaMaker a : slView.jlMediaMaker.getSelectedValuesList()) {
					model.deleteObject(a);
				}
			}
			else if (slView.jrbActors.isSelected()) {
				for (MediaMaker ac : slView.jlMediaMaker.getSelectedValuesList()) {
					model.deleteObject((Actor)ac);
				}
			}
			else if (slView.jrbDirectors.isSelected()) {
				for (MediaMaker di : slView.jlMediaMaker.getSelectedValuesList()) {
					model.deleteObject((Director)di);
				}
			}
			else if (slView.jrbProducers.isSelected()) {
				for (MediaMaker pr : slView.jlMediaMaker.getSelectedValuesList()) {
					model.deleteObject((Producer)pr);
				}
			}
			System.out.println(model.getMediaMakerObjects());//Tests model post conditions.
		}
	}

	private class AddClearListener implements ActionListener {

		public String getSelectedButtonText() {
			String result = "";
			for (Component a : slView.buttonList.getComponents()) {

				if (((JRadioButton) a).isSelected()) {
					result = ((JRadioButton) a).getText();
				}
			}
			return result;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Clear");
			model.clear(getSelectedButtonText());
			slView.refireSelectedButton();
			System.out.println(model.getMediaObjects());
		}
	}

	private class AddClearAllListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Clear All");
			model.clearAll();

		}
	}

	// Create private class listeners for the JMenu jmDisplay
	private class AddPieChartListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("PieChart");
		}
	}

	private class AddHistogramListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Histogram");
			 for(MediaMaker a: slView.jlMediaMaker.getSelectedValuesList()){
			 	JFrame frame = new JFrame();
			 frame.setSize(900,600);
			 frame.add(new Histogram(a));
			 frame.setVisible(true);
			 		}
			  	}
		}

	/**
	 * This method will set the MediaModel for this controller
	 * 
	 * @param newModel
	 *            The MediaModel to be assigned to this controller
	 */
	public void setModel(MediaModel newModel) {
		this.model = newModel;
	}

	/**
	 * This method will return the MediaModel associated with this controller
	 * 
	 * @return The MediaModel associated with this controller
	 */
	public MediaModel getModel() {
		return this.model;
	}

	/**
	 * This method will set the SelectionView for this controller, as well as
	 * register all listeners associated with that SelectionView
	 * 
	 * @param view
	 *            The SelectionView to be assigned to the controller
	 */
	public void setSelectionView(SelectionView view) {
		this.slView = view;

		// Register listeners for the radio buttons in the SelectionView slView
		slView.addMediaButtonListener(new AddMediaListener());
		slView.addMoviesButtonListener(new AddMoviesListener());
		slView.addSeriesButtonListener(new AddSeriesListener());
		slView.addEpisodeButtonListener(new AddEpisodesListener());
		slView.addMakersButtonListener(new AddMakersListener());
		slView.addActorsButtonListener(new AddActorsListener());
		slView.addDirectorsButtonListener(new AddDirectorsListener());
		slView.addProducersButtonListener(new AddProducersListener());

		// Register listeners for the JMenu jmFile in the SelectionView slView
		slView.addSaveButtonListener(new AddSaveListener());
		slView.addLoadButtonListener(new AddLoadListener());
		slView.addImportButtonListener(new AddImportListener());
		slView.addExportButtonListener(new AddExportListener());

		// Register listeners for the JMenu jmEdit in the SelectionView slView
		slView.addAddButtonListener(new AddAddListener());
		slView.addEditButtonListener(new AddEditListener());
		slView.addDeleteButtonListener(new AddDeleteListener());
		slView.addClearButtonListener(new AddClearListener());
		slView.addClearAllButtonListener(new AddClearAllListener());

		// Register listeners for the JMenu jmDisplay in the SelectionView
		// slView
		slView.addPieChartButtonListener(new AddPieChartListener());
		slView.addHistogramButtonListener(new AddHistogramListener());
		
		model.addActionListener(slView);
	}
	
	/**
	 * Sets the AddView for this controller 
	 * 
	 * @param view		AddView to be set
	 */
	public void setAddView(AddView view) {
		this.addView = view;
		
		addView.addAddButtonListener(new AddAddButtonListener());
		
		model.addActionListener(view);
	}
	
	/**
	 * Sets the EditView for this Controller
	 * 
	 * @param view		EditView to be set
	 */
	public void setEditView(EditView view) {
		this.editView = view;
		
		editView.addEditButtonListener(new AddEditButtonListener());
	}

	/**
	 * This method will return the SelectionView associated with this controller
	 * 
	 * @return The SelectionView associated with this controller
	 */
	public SelectionView getSelectionView() {
		return this.slView;
	}

}