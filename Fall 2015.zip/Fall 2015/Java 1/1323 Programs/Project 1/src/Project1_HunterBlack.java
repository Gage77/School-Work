/** This program prints out fun facts about CS.
 * @author Hunter
 * @version 1.0
 * I copied this code from the Project 1 Handout, but it's OK because Dr. Trytten
 * told me to.
 */
public class Project1_HunterBlack 
{

	//This is the main program. The instructions here
	//are what is done when the program is run
	public static void main(String[] args)
	{
		System.out.println("Hello world.");	
	}
}
